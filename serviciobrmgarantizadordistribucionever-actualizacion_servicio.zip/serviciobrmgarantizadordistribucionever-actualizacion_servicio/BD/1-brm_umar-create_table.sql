USE [BRM_Liner]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Proyecto: Distribución EVER - Carpeta: BL - Tabla: BL
CREATE TABLE [dbo].[tbDistribucionEVERBl](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar](5) NULL,
	[BL] [varchar](100) NULL,
	[Contenedor] [varchar](100) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar](100) NULL,
	[Deposito] [varchar] (5) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Exento - Tabla: Exento
CREATE TABLE [dbo].[tbDistribucionEVERClienteEspecial](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,		
	[PuertoOrigen] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar] (100) NULL,
	[CuotaCantidad] [float] NULL,
	[CuotaDeposito] [varchar](5) NULL,
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Descuento - Tabla: Descuento
CREATE TABLE [dbo].[tbDistribucionEVERContrato](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[PuertoEmbarque] [varchar] (50),		
	[Contrato] [varchar](20) NULL,		
	[Deposito] [varchar](100) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Especial - Tabla: Especial
CREATE TABLE [dbo].[tbDistribucionEVERRecalada](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[Nave] [varchar] (20),		
	[Viaje] [varchar](20) NULL,		
	[Destino] [varchar](100) NULL,
	[Descarga] [varchar](20) NULL,	
	[PiesTipo] [varchar] (10) NULL,
	[NOR] [varchar](100) NULL,
	[DistribucionDeposito] [varchar](10) NULL,
	[DistribucionPorcentaje] [float] NULL,
	[DistribucionTolerancia] [varchar](20) NULL,
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

CREATE TABLE [dbo].[tbDistribucionEVERRut](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,		
	[PuertoDescarga] [varchar](50) NULL,
	[PuertoEmbarque] [varchar](50) NULL,
	[Contenedor] [varchar](50) NULL,
	[BL] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar] (100) NULL,
	[Deposito] [varchar](5) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

CREATE TABLE [dbo].[tbDistribucionEVERRutPorcentual](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,	
	[PuertoDescarga] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[DistribucionDeposito] [varchar](50) NULL,
	[DistribucionPorcentaje] [varchar](50) NULL,
	[DistribucionTolerancia] [varchar](10) NULL,			
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

CREATE TABLE [dbo].[tbDistribucionEVERBlHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar](5) NULL,
	[BL] [varchar](100) NULL,
	[Contenedor] [varchar](100) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar](100) NULL,
	[Deposito] [varchar] (5) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Exento - Tabla: Exento
CREATE TABLE [dbo].[tbDistribucionEVERClienteEspecialHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,		
	[PuertoOrigen] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar] (100) NULL,
	[CuotaCantidad] [float] NULL,
	[CuotaDeposito] [varchar](5) NULL,
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Descuento - Tabla: Descuento
CREATE TABLE [dbo].[tbDistribucionEVERContratoHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[PuertoEmbarque] [varchar] (50),		
	[Contrato] [varchar](20) NULL,		
	[Deposito] [varchar](100) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

-- Proyecto: Distribución EVER - Carpeta: Especial - Tabla: Especial
CREATE TABLE [dbo].[tbDistribucionEVERRecaladaHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[Nave] [varchar] (20),		
	[Viaje] [varchar](20) NULL,		
	[Destino] [varchar](100) NULL,
	[Descarga] [varchar](20) NULL,	
	[PiesTipo] [varchar] (10) NULL,
	[NOR] [varchar](100) NULL,
	[DistribucionDeposito] [varchar](10) NULL,
	[DistribucionPorcentaje] [float] NULL,
	[DistribucionTolerancia] [varchar](20) NULL,
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

CREATE TABLE [dbo].[tbDistribucionEVERRutHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,		
	[PuertoDescarga] [varchar](50) NULL,
	[PuertoEmbarque] [varchar](50) NULL,
	[Contenedor] [varchar](50) NULL,
	[BL] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[NOR] [varchar] (100) NULL,
	[Deposito] [varchar](5) NULL,	
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO

CREATE TABLE [dbo].[tbDistribucionEVERRutPorcentualHistorica](
	[Id] [numeric](25, 0) PRIMARY KEY,	
	[FechaVigenciaDesde] [date] NULL,
	[FechaVigenciaHasta] [date] NULL,
	[Operador] [varchar] (5),	
	[RutConsignatario] [varchar] (20),		
	[RutClientePaga] [varchar](20) NULL,	
	[PuertoDescarga] [varchar](50) NULL,
	[PiesTipo] [varchar](10) NULL,	
	[DistribucionDeposito] [varchar](50) NULL,
	[DistribucionPorcentaje] [varchar](50) NULL,
	[DistribucionTolerancia] [varchar](10) NULL,			
	[Creador] [varchar](20) NULL,
	[FechaCreacion] [datetime2](7) NULL,
	[Actualizador] [varchar](20) NULL,
	[FechaModificacion] [datetime2](7) NULL,
	[Activo] [bit] NULL,
	[Visible] [bit] NULL)
GO