USE [BRM_Liner]
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN31 Base - Tabla: Base

CREATE SEQUENCE [dbo].[SeqDistribucionEVERBl] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN32 Exenciones - Tabla: Exento
CREATE SEQUENCE [dbo].[SeqDistribucionEVERClienteEspecial] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN33 Descuentos - Tabla: Descuento
CREATE SEQUENCE [dbo].[SeqDistribucionEVERContrato] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRecalada] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRut] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRutPorcentual] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

CREATE SEQUENCE [dbo].[SeqDistribucionEVERBlHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN32 Exenciones - Tabla: Exento
CREATE SEQUENCE [dbo].[SeqDistribucionEVERClienteEspecialHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN33 Descuentos - Tabla: Descuento
CREATE SEQUENCE [dbo].[SeqDistribucionEVERContratoHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRecaladaHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRutHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO

-- Proyecto: Emision Certificados UMAR - Carpeta: RN34 Especiales- Tabla: Especial
CREATE SEQUENCE [dbo].[SeqDistribucionEVERRutPorcentualHistorica] 
 AS [bigint]
 START WITH 1
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 CACHE 
GO
