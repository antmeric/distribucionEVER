USE [BRM_Application]
GO

-- Generar Proyecto: Correctores COLU
INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'BRM Distribución EVER', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER', N'ULTRAMAR', 0, 1, 0, 0, NULL)

-- Generar Carpetas: RN31 Base - RN32 Exenciones - RN33 Descuentos - RN34 Especiales
INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta BL', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_EMI_DIS_EVER_BL', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta Cliente Especial', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_CESP', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta Contrato', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_CONT', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta Recalada', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_REC', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta Rut', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_RUT', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Carpeta Rut Porcentual', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_RUTP', N'ULTRAMAR', 0, 2, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'), 0, NULL)

-- Generar Tablas: Base - Exento - Descuento - Especial
INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación BL', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_BL_BL', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación Cliente Especial', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_CESP_CESP', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación Contrato', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_CONT_CONT', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación por Recalada', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_REC_REC', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación Rut', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_RUT_RUT', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)

INSERT [dbo].[TbBrmQuery] ([Name], [Area], [Server], [DataBase], [User], [Password], [Type], [Port], [Sid], [Access], [Company], [Tramos], [Jerarquia], [IdBrmQueryPadre], [TablasDinamicas], [TablasDinamicasVariable]) 
VALUES (N'Tabla Asignación Porcentual Rut', NULL, N'cassian-dev.kerkuz.com', N'BRM_Liner', N'usr_brmliner', N'N2ZiaW9rQTYmSnpjZjdORw==', N'SQLSERVER', 1433, NULL, N'BRM_MANT_DIS_EVER_RUTP_RUTP', N'ULTRAMAR', 0, 3, (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')), 0, NULL)


