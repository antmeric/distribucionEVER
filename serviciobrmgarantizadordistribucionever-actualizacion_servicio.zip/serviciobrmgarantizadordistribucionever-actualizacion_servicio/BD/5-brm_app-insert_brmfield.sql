USE [BRM_Application]
GO

-- Proyecto: Tarifas UMAR - Carpeta: RN31 Base - Tabla: Base
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'BL', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'BL', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Contenedor', N'varchar', 1, N'^[A-Za-z0-9_-]{1,100}|ALL$', N'Alfanumérico de máximo 100 caracteres (ALL para regla genérica)', 1, 1, N'Contenedor', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PiesTipo', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'PiesTipo', 0, 0, N'G')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'NOR', N'varchar', 1, N'^ALL|FALSE|TRUE$', N'FALSE, TRUE o ALL para genérica', 1, 1, N'NOR', 0, 0, N'H')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Deposito', N'varchar', 1, N'^[A-Za-z0-9_]{1,5}$', N'Alfanumérico de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Deposito', 0, 0, N'I')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'N')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'O');




-- Proyecto: Tarifas UMAR - Carpeta: RN32 Exenciones - Tabla: Asignación Cliente Recalada
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutConsignatario', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutConsignatario', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutClientePaga', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutClientePaga', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PuertoOrigen', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'PuertoOrigen', 0, 0, N'G')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PiesTipo', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'PiesTipo', 0, 0, N'H')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'NOR', N'varchar', 1, N'^ALL|FALSE|TRUE$', N'FALSE, TRUE o ALL para genérica', 1, 1, N'NOR', 0, 0, N'I')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'CuotaCantidad', N'decimal', 1, N'^(0|[1-9]\d*)(\.\d+)?$', N'Numero decimal con punto', 1, 1, N'CuotaCantidad', 0, 0, N'J')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'CuotaDeposito', N'varchar', 1, N'^[A-Za-z0-9_]{1,5}$', N'Alfanumérico de hasta 5 letras (ALL para regla genérica)' , 1, 1, N'CuotaDeposito', 0, 0, N'K')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'P')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'Q');

-- Proyecto: Tarifas UMAR - Carpeta: RN33 Contratos - Tabla: Contrato
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PuertoEmbarque', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 100 caracteres (ALL para regla genérica)', 1, 1, N'PuertoEmbarque', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Contrato', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'Contrato', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Deposito', N'varchar', 1, N'^[A-Za-z0-9_]{1,5}$', N'Alfanumérico de hasta 5 letras (ALL para regla genérica)' , 1, 1, N'Deposito', 0, 0, N'G')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'L')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'M');

-- Proyecto: Tarifas UMAR - Carpeta: RN34 Recaladaes - Tabla: Recalada
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Nave', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'Nave', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Viaje', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'Viaje', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Destino', N'varchar', 1, N'^[A-Za-z0-9_]{1,100}|ALL$', N'Alfanumérico de máximo 100 caracteres (ALL para regla genérica)', 1, 1, N'Destino', 0, 0, N'G')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Descarga', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'Descarga', 0, 0, N'H')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PiesTipo', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'PiesTipo', 0, 0, N'I')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'NOR', N'varchar', 1, N'^ALL|FALSE|TRUE$', N'FALSE, TRUE o ALL para genérica', 1, 1, N'NOR', 0, 0, N'J')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionDeposito',N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'DistribucionDeposito', 0, 0, N'K')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionPorcentaje', N'decimal', 1, N'^(0|[1-9]\d*)(\.\d+)?$', N'Numero decimal con punto', 1, 1, N'DistribucionPorcentaje', 0, 0, N'L')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionTolerancia', N'varchar', 1, N'^[A-Za-z0-9_]{1,20}|ALL$', N'Alfanumérico de máximo 20 caracteres (ALL para regla genérica)', 1, 1, N'DistribucionTolerancia', 0, 0, N'M')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'R')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'S');

-- RUT

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutConsignatario', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutConsignatario', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutClientePaga', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutClientePaga', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PuertoDescarga', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'PuertoDescarga', 0, 0, N'G')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PuertoEmbarque', N'varchar', 1, N'^[A-Za-z0-9_/]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'PuertoEmbarque', 0, 0, N'H')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'BL', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'BL', 0, 0, N'I')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Contenedor', N'varchar', 1, N'^[A-Za-z0-9_/]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'Contenedor', 0, 0, N'J')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PiesTipo', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'PiesTipo', 0, 0, N'K')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'NOR', N'varchar', 1, N'^ALL|FALSE|TRUE$', N'FALSE, TRUE o ALL para genérica', 1, 1, N'NOR', 0, 0, N'L')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Deposito', N'varchar', 1, N'^[A-Za-z0-9_]{1,5}$', N'Alfanumérico de hasta 5 letras (ALL para regla genérica)' , 1, 1, N'Deposito', 0, 0, N'M')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'R')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'S');


-- RUT PORCENTUAL

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Id', N'id', 0, NULL, NULL, 0, 0, N'Id', 0, 0, N'A')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaDesde', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaDesde', 0, 0, N'B')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaVigenciaHasta', N'date', 1, N'^[0-9]{4}-[0-9]{2}-[0-9]{2}', N'Fecha en formato YYYY-MM-DD', 1, 1, N'FechaVigenciaHasta', 0, 0, N'C')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Operador', N'varchar', 1, N'^[A-Za-z]{1,5}|ALL$', N'Código de hasta 5 letras (ALL para regla genérica)', 1, 1, N'Operador', 0, 0, N'D')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutConsignatario', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutConsignatario', 0, 0, N'E')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'RutClientePaga', N'varchar', 1, N'^[0-9]{1,8}-[0-9Kk]{1}|ALL$', N'RUT con guión y sin puntos (ALL para regla genérica)', 1, 1, N'RutClientePaga', 0, 0, N'F')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PuertoDescarga', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'PuertoDescarga', 0, 0, N'G')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'PiesTipo', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}|ALL$', N'Alfanumérico de máximo 10 caracteres (ALL para regla genérica)', 1, 1, N'PiesTipo', 0, 0, N'H')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionDeposito', N'varchar', 1, N'^[A-Za-z0-9_]{1,50}|ALL$', N'Alfanumérico de máximo 50 caracteres (ALL para regla genérica)', 1, 1, N'DistribucionDeposito', 0, 0, N'I')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionPorcentaje', N'decimal', 1, N'^(0|[1-9]\d*)(\.\d+)?$', N'Numero decimal con punto', 1, 1, N'DistribucionPorcentaje', 0, 0, N'J')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'DistribucionTolerancia', N'varchar', 1, N'^[A-Za-z0-9_]{1,10}$', N'Alfanumérico de hasta 5 letras (ALL para regla genérica)' , 1, 1, N'DistribucionTolerancia', 0, 0, N'K')

INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Creador', N'varchar', 0, NULL, NULL, 0, 0, N'Creador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaCreacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaCreacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Actualizador', N'varchar', 0, NULL, NULL, 0, 0, N'Actualizador', 1, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'FechaModificacion', N'datetime', 0, NULL, NULL, 0, 0, N'FechaModificacion', 0, 0, NULL)
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Activo', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 1, 1, N'Activo', 0, 0, N'P')
INSERT [dbo].[TbBrmField] ([IdBs], [Campo], [Tipo], [Editable], [Format], [Validacion], [Insertable], [Requerido], [Descripcion], [Auditoria], [Tramo], [ColumnaExcel])
VALUES ((SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER'))),
N'Visible', N'boolean', 1, N'^[0-1]$', N'Verdadero o falso', 0, 0, N'Visible', 0, 0, N'Q');

