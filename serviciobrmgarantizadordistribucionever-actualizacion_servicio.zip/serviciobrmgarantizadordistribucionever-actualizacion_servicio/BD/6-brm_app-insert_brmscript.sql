USE [BRM_Application]
GO

-- Proyecto: Tarifas COLU - Carpeta:  Base - Tabla: Base
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
	  ,N'SELECT [Id]
        ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
      ,[Operador]
      ,[BL]
      ,[Contenedor]            
      ,[PiesTipo]
      ,[NOR]
      ,[Deposito]      
	,Activo
	,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERBl]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
	  ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERBl as decimal(25,0))as Id', N'SEQ_RULE')        
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
	,N'UPDATE [dbo].[tbDistribucionEVERBl]
	SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,[Operador] = @Operador
      ,[BL] = @BL
      ,[Contenedor] = @Contenedor            
      ,[PiesTipo] = @PiesTipo
      ,[NOR] = @NOR
      ,[Deposito] = @Deposito      
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
	,Visible = @Visible
	,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
	 ,N'INSERT INTO [dbo].[tbDistribucionEVERBl]
           ([Id]
           ,[FechaVigenciaDesde]
           ,[FechaVigenciaHasta]
           ,[Operador]
           ,[BL]
           ,[Contenedor]                      
           ,[PiesTipo]
           ,[NOR]
           ,[Deposito]           
           ,[Creador]
           ,[FechaCreacion]
           ,[Actualizador]
           ,[FechaModificacion]
	      ,[Activo]
	 	,[Visible])
     VALUES
           (@Id
           ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
           ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
           ,@Operador
           ,@BL
           ,@Contenedor           
           ,@PiesTipo
           ,@NOR
           ,@Deposito           
           ,@Creador
           ,GETDATE()
           ,@Actualizador
           ,GETDATE()
		,@Activo
		,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERBl] 
where Operador = @Operador AND BL = @BL AND Contenedor = @Contenedor AND PiesTipo = @PiesTipo AND NOR = @NOR 
AND Deposito = @Deposito
AND (
	(PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)	
	OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)	
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
	OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)	
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
And Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación BL' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta BL'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERBl] 
where Operador = @Operador AND BL = @BL AND Contenedor = @Contenedor AND PiesTipo = @PiesTipo AND NOR = @NOR 
AND Deposito = @Deposito
AND (
	(PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)	
	OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)	
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
	OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)	
	OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')

-- Proyecto: Tarifas COLU - Carpeta:  Exenciones - Tabla: Exento
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT [Id]  
        ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
      ,[Operador]     
      ,[RutConsignatario]  
      ,[RutClientePaga]                  
      ,[PuertoOrigen]
      ,[PiesTipo]          
      ,[NOR]   
      ,[CuotaCantidad]
      ,[CuotaDeposito]  
      ,Activo
      ,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERClienteEspecial]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERClienteEspecial as decimal(25,0))as Id', N'SEQ_RULE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
      ,N'UPDATE [dbo].[tbDistribucionEVERClienteEspecial]
      SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,[Operador] = @Operador
      ,[RutConsignatario] = @RutConsignatario 
      ,[RutClientePaga] = @RutClientePaga       
      ,[PuertoOrigen] = @PuertoOrigen
      ,[PiesTipo] = @PiesTipo                    
      ,[NOR] = @NOR  
      ,[CuotaCantidad] = @CuotaCantidad
      ,[CuotaDeposito] = @CuotaDeposito
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
      ,Visible = @Visible
      ,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
       ,N'INSERT INTO [dbo].[tbDistribucionEVERClienteEspecial]
      ([Id]
      ,[FechaVigenciaDesde] 
      ,[FechaVigenciaHasta]
      ,[Operador]
      ,[RutConsignatario]
      ,[RutClientePaga]              
      ,[PuertoOrigen]      
      ,[PiesTipo]      
      ,[NOR]   
      ,[CuotaCantidad]            
      ,[CuotaDeposito]            
           ,[Creador]
           ,[FechaCreacion]
           ,[Actualizador]
           ,[FechaModificacion]
            ,[Activo]
            ,[Visible])
     VALUES
      (@Id
      ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
     ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,@Operador
      ,@RutConsignatario
      ,@RutClientePaga               
      ,@PuertoOrigen
      ,@PiesTipo     
     ,@NOR
     ,@CuotaCantidad
     ,@CuotaDeposito                   
     ,@Creador
     ,GETDATE()
     ,@Actualizador
           ,GETDATE()
            ,@Activo
            ,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERClienteEspecial] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND  PuertoOrigen = @PuertoOrigen AND PiesTipo = @PiesTipo AND NOR = @NOR AND CuotaCantidad = @CuotaCantidad
AND CuotaDeposito = @CuotaDeposito AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
AND Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Cliente Especial' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Cliente Especial'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERClienteEspecial] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND  PuertoOrigen = @PuertoOrigen AND PiesTipo = @PiesTipo AND NOR = @NOR AND CuotaCantidad = @CuotaCantidad
AND CuotaDeposito = @CuotaDeposito AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')



-- Proyecto: Tarifas COLU - Carpeta:  Descuentos - Tabla: Descuento
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT [Id]
        ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
        ,[Operador]  
        ,[PuertoEmbarque]
      ,[Contrato]     
	,[Deposito] 	
      ,Activo
      ,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERContrato]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERContrato as decimal(25,0))as Id', N'SEQ_RULE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
      ,N'UPDATE [dbo].[tbDistribucionEVERContrato]
      SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,[Operador] = @Operador
      ,[PuertoEmbarque] = @PuertoEmbarque 
      ,[Contrato] = @Contrato             
	,[Deposito]  = @Deposito      	      
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
      ,Visible = @Visible
      ,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
       ,N'INSERT INTO [dbo].[tbDistribucionEVERContrato]
           ([Id]
           ,[FechaVigenciaDesde] 
            ,[FechaVigenciaHasta] 
            ,[Operador]
            ,[PuertoEmbarque]
            ,[Contrato]        
	      ,[Deposito] 	      
            ,[Creador] 
            ,[FechaCreacion] 
            ,[Actualizador]  
            ,[FechaModificacion] 
            ,[Activo] 
            ,[Visible]) 
     VALUES
            (@Id
            ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
            ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
            ,@Operador
            ,@PuertoEmbarque
            ,@Contrato        
            ,@Deposito            
            ,@Creador
            ,GETDATE()
            ,@Actualizador
            ,GETDATE()
            ,@Activo
     ,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERContrato] 
WHERE Operador = @Operador AND  PuertoEmbarque = @PuertoEmbarque AND  Contrato= @Contrato
AND Deposito = @Deposito AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
And Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Contrato' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Contrato'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERContrato] 
WHERE Operador = @Operador AND  PuertoEmbarque = @PuertoEmbarque AND  Contrato= @Contrato
AND Deposito = @Deposito AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')


-- Proyecto: Tarifas COLU - Carpeta:  Especiales - Tabla: Especial
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
         ,N'SELECT [Id]       
         ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
         ,[Operador]
         ,[Nave]
      ,[Viaje]        
      ,[Destino]
      ,[Descarga]          
      ,[PiesTipo]
      ,[NOR]
      ,[DistribucionDeposito]
      ,[DistribucionPorcentaje]
      ,[DistribucionTolerancia]               
      ,Activo
      ,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERRecalada]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERRecalada as decimal(25,0))as Id', N'SEQ_RULE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
      ,N'UPDATE [dbo].[tbDistribucionEVERRecalada]
      SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')      
      ,[Operador] = @Operador
      ,[Nave] = @Nave
      ,[Viaje] = @Viaje 
      ,[Destino] = @Destino
      ,[Descarga] = @Descarga
      ,[PiesTipo] = @PiesTipo
      ,[NOR] = @NOR
      ,[DistribucionDeposito] = @DistribucionDeposito
      ,[DistribucionPorcentaje] = @DistribucionPorcentaje
      ,[DistribucionTolerancia] = @DistribucionTolerancia
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
      ,Visible = @Visible
      ,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
       ,N'INSERT INTO [dbo].[tbDistribucionEVERRecalada]
         ([Id]
         ,[FechaVigenciaDesde] 
      ,[FechaVigenciaHasta]
         ,[Operador]
         ,[Nave]
      ,[Viaje]        
      ,[Destino]
      ,[Descarga]          
      ,[PiesTipo]
      ,[NOR]
      ,[DistribucionDeposito]
      ,[DistribucionPorcentaje]
      ,[DistribucionTolerancia]      
      ,[Creador]
           ,[FechaCreacion]
           ,[Actualizador]
           ,[FechaModificacion]
	      ,[Activo]
	 	,[Visible])      
     VALUES
             (@Id
             ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
           ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
             ,@Operador
         ,@Nave
      ,@Viaje        
      ,@Destino
      ,@Descarga          
      ,@PiesTipo
      ,@NOR
      ,@DistribucionDeposito
      ,@DistribucionPorcentaje
      ,@DistribucionTolerancia      
           ,@Creador
           ,GETDATE()
           ,@Actualizador
           ,GETDATE()
            ,@Activo
            ,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRecalada] 
WHERE Operador = @Operador AND  Nave = @Nave AND  Viaje= @Viaje AND Destino = @Destino AND Descarga = @Descarga 
AND  PiesTipo = @PiesTipo AND NOR = @NOR AND DistribucionDeposito = @DistribucionDeposito AND DistribucionPorcentaje = @DistribucionPorcentaje 
AND DistribucionTolerancia = @DistribucionTolerancia
AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
And Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación por Recalada' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Recalada'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRecalada] 
WHERE Operador = @Operador AND  Nave = @Nave AND  Viaje= @Viaje AND Destino = @Destino AND Descarga = @Descarga 
AND  PiesTipo = @PiesTipo AND NOR = @NOR AND DistribucionDeposito = @DistribucionDeposito AND DistribucionPorcentaje = @DistribucionPorcentaje 
AND DistribucionTolerancia = @DistribucionTolerancia
AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')





-- Proyecto: Tarifas COLU - Carpeta:  Exenciones - Tabla: Exento
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT [Id]  
        ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
      ,[Operador]     
      ,[RutConsignatario]  
      ,[RutClientePaga]                  
      ,[PuertoDescarga]
      ,[PuertoEmbarque]
      ,[BL]
      ,[Contenedor]      
      ,[PiesTipo]          
      ,[NOR]   
      ,[Deposito]      
      ,Activo
      ,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERRut]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERRut as decimal(25,0))as Id', N'SEQ_RULE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
      ,N'UPDATE [dbo].[tbDistribucionEVERRut]
      SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,[Operador] = @Operador
      ,[RutConsignatario]  = @RutConsignatario
      ,[RutClientePaga] = @RutClientePaga                 
      ,[PuertoDescarga] = @PuertoDescarga
      ,[PuertoEmbarque] = @PuertoEmbarque
      ,[BL] = @BL
      ,[Contenedor] = @Contenedor
      ,[PiesTipo] = @PiesTipo          
      ,[NOR] = @NOR
      ,[Deposito] = @Deposito
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
      ,Visible = @Visible
      ,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
       ,N'INSERT INTO [dbo].[tbDistribucionEVERRut]
      ([Id]
      ,[FechaVigenciaDesde] 
      ,[FechaVigenciaHasta]
      ,[Operador]     
      ,[RutConsignatario]  
      ,[RutClientePaga]                  
      ,[PuertoDescarga]
      ,[PuertoEmbarque]
      ,[BL]
      ,[Contenedor]
      ,[PiesTipo]          
      ,[NOR]   
      ,[Deposito]            
           ,[Creador]
           ,[FechaCreacion]
           ,[Actualizador]
           ,[FechaModificacion]
            ,[Activo]
            ,[Visible])
     VALUES
      (@Id
      ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
     ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,@Operador     
      ,@RutConsignatario  
      ,@RutClientePaga                  
      ,@PuertoDescarga
      ,@PuertoEmbarque
      ,@BL
      ,@Contenedor
      ,@PiesTipo          
      ,@NOR   
      ,@Deposito                 
     ,@Creador
     ,GETDATE()
     ,@Actualizador
           ,GETDATE()
            ,@Activo
            ,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRut] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND  PuertoDescarga = @PuertoDescarga AND PiesTipo = @PiesTipo AND NOR = @NOR AND BL = @BL AND Contenedor = @Contenedor
AND Deposito = @Deposito AND PuertoEmbarque = @PuertoEmbarque AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
AND Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRut] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND  PuertoDescarga = @PuertoDescarga AND PiesTipo = @PiesTipo AND NOR = @NOR AND BL = @BL AND Contenedor = @Contenedor
AND Deposito = @Deposito AND PuertoEmbarque = @PuertoEmbarque AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')




-- Proyecto: Tarifas COLU - Carpeta:  Exenciones - Tabla: Exento
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT [Id]  
        ,format(FechaVigenciaDesde,''yyyy-MM-dd'') as FechaVigenciaDesde
      ,format(FechaVigenciaHasta,''yyyy-MM-dd'') as FechaVigenciaHasta
      ,[Operador]     
      ,[RutConsignatario]  
      ,[RutClientePaga]    
      ,[PuertoDescarga]
      ,[PiesTipo]              
      ,[DistribucionDeposito]
      ,[DistribucionPorcentaje]          
      ,[DistribucionTolerancia]           
      ,Activo
      ,Visible
      ,[Creador]
      ,format(FechaCreacion,''yyyy-MM-dd HH:mm:ss'') AS FechaCreacion
      ,[Actualizador]
      ,format(FechaModificacion,''yyyy-MM-dd HH:mm:ss'') AS FechaModificacion
  FROM [dbo].[tbDistribucionEVERRutPorcentual]
  WHERE Visible = 1
  ORDER BY Id ASC', N'SELECT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
        ,N'SELECT cast(NEXT VALUE FOR SeqDistribucionEVERRutPorcentual as decimal(25,0))as Id', N'SEQ_RULE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
      ,N'UPDATE [dbo].[tbDistribucionEVERRutPorcentual]
      SET [FechaVigenciaDesde] = PARSE(@FechaVigenciaDesde as date using ''es-CL'')
      ,[FechaVigenciaHasta] = PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,[Operador] = @Operador
      ,[RutConsignatario] = @RutConsignatario 
      ,[RutClientePaga] = @RutClientePaga       
      ,[PuertoDescarga] = @PuertoDescarga 
      ,[PiesTipo] = @PiesTipo 
      ,[DistribucionDeposito] = @DistribucionDeposito
      ,[DistribucionPorcentaje] = @DistribucionPorcentaje
      ,[DistribucionTolerancia] = @DistribucionTolerancia
      ,[Actualizador] = @Actualizador
      ,[FechaModificacion] = GETDATE()
      ,Visible = @Visible
      ,Activo = CASE WHEN @Visible = ''false'' THEN @Visible ELSE @Activo END
 WHERE [Id] = @Id', N'UPDATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
       ,N'INSERT INTO [dbo].[tbDistribucionEVERRutPorcentual]
      ([Id]
      ,[FechaVigenciaDesde] 
      ,[FechaVigenciaHasta]
      ,[Operador]
      ,[RutConsignatario]
      ,[RutClientePaga]              
      ,[PuertoDescarga]
      ,[PiesTipo]
      ,[DistribucionDeposito]
      ,[DistribucionPorcentaje]          
      ,[DistribucionTolerancia]        
           ,[Creador]
           ,[FechaCreacion]
           ,[Actualizador]
           ,[FechaModificacion]
            ,[Activo]
            ,[Visible])
     VALUES
      (@Id
      ,PARSE(@FechaVigenciaDesde as date using ''es-CL'')
     ,PARSE(@FechaVigenciaHasta as date using ''es-CL'')
      ,@Operador
      ,@RutConsignatario
      ,@RutClientePaga               
      ,@PuertoDescarga 
      ,@PiesTipo 
      ,@DistribucionDeposito
      ,@DistribucionPorcentaje          
      ,@DistribucionTolerancia                    
     ,@Creador
     ,GETDATE()
     ,@Actualizador
           ,GETDATE()
            ,@Activo
            ,''true'')', N'INSERT')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRutPorcentual] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND PuertoDescarga = @PuertoDescarga AND PiesTipo = @PiesTipo 
AND  DistribucionDeposito = @DistribucionDeposito AND DistribucionPorcentaje = @DistribucionPorcentaje 
AND DistribucionTolerancia = @DistribucionTolerancia AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
)
AND Activo = @Activo', N'DUPLICATE')
INSERT [dbo].[TbBrmScript] ([IdBq], [Query], [Tipo]) VALUES (
(SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Tabla Asignación Porcentual Rut' AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'Carpeta Rut Porcentual'
AND [IdBrmQueryPadre] = (SELECT [Id] FROM [dbo].[TbBrmQuery] WHERE [Name] = 'BRM Distribución EVER')))
,N'select COUNT(1) as DUPLICATE from [tbDistribucionEVERRutPorcentual] 
WHERE RutClientePaga = @RutClientePaga AND  RutConsignatario = @RutConsignatario AND  Operador= @Operador
AND PuertoDescarga = @PuertoDescarga AND PiesTipo = @PiesTipo
AND  DistribucionDeposito = @DistribucionDeposito AND DistribucionPorcentaje = @DistribucionPorcentaje 
AND DistribucionTolerancia = @DistribucionTolerancia AND (
      (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') >= FechaVigenciaDesde)
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') = FechaVigenciaDesde)  
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') = FechaVigenciaHasta)  
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaHasta)
      OR (PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') < FechaVigenciaHasta)    
      OR (PARSE(@FechaVigenciaDesde as date using ''es-CL'') < FechaVigenciaDesde AND PARSE(@FechaVigenciaHasta as date using ''es-CL'') > FechaVigenciaHasta)
) AND Id != @Id And Activo = 1
And Activo = @Activo', N'UPD_DUP')



