USE [BRM_LINER]
GO

CREATE TABLE [dbo].[tbDistribucionEVERConfig] (
	Id [numeric](25, 0) PRIMARY KEY,
	NombreTabla [varchar](50) NOT NULL,
	Valor [bit] NOT NULL,
	Descripcion [varchar](50) NOT NULL	
);

INSERT [dbo].[tbDistribucionEVERConfig] ([Id], [NombreTabla], [Valor], [Descripcion]) VALUES (1, N'tbDistribucionEVERClienteEspecial', N'1', N'Tabla Cliente Especial')
INSERT [dbo].[tbDistribucionEVERConfig] ([Id], [NombreTabla], [Valor], [Descripcion]) VALUES (2, N'tbDistribucionEVERRecalada', N'1', N'Tabla Recalada')
INSERT [dbo].[tbDistribucionEVERConfig] ([Id], [NombreTabla], [Valor], [Descripcion]) VALUES (3, N'tbDistribucionEVERRutPorcentual', N'1', N'Tabla Rut Porcentual')