﻿using EvolveDb;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DbMigrationLib
{
    public class DbMigrationsBuilder
    {

        private string _stringConnection;
        private string _path = "db2/migrations";
        private ILogger _Logger;
        private bool Reparar = false;

        public static DbMigrationsBuilder Crear()
        {
            return new DbMigrationsBuilder();
        }

        public DbMigrationsBuilder AddStringConection(string stringConnection)
        {
            _stringConnection = stringConnection;
            return this;
        }
        public DbMigrationsBuilder AddPath(string path)
        {
            _path = path;
            return this;
        }
        public DbMigrationsBuilder AddILogger(ILogger logger)
        {
            _Logger = logger;
            return this;
        }
        public DbMigrationsBuilder RepararDb(bool valor)
        {
            Reparar = valor;
            return this;
        }

        public void Build()
        {

            if (_stringConnection == null)
            {
                throw new ArgumentException("falta String de conexión");
            }
            if (_Logger == null)
            {
                throw new ArgumentException("falta logger");
            }
            try
            {
                _Logger.LogDebug(_path);
                using (var conexion = new SqlConnection(_stringConnection))
                {
                    var evolve = new Evolve(conexion, msg => _Logger.LogDebug(msg))
                    {
                        Locations = new[] { _path },
                        IsEraseDisabled = true,
                        Placeholders = new Dictionary<string, string>
                        {
                            ["${table4}"] = "table4"
                        }
                    };
                    if (Reparar) { evolve.Repair(); }
                    evolve.Migrate();
                }
            }
            catch (Exception ex)
            {
                _Logger.LogError(ex.ToString());
                //TODO poner una excepcion en la aplicación
            }
        }

    }
}
