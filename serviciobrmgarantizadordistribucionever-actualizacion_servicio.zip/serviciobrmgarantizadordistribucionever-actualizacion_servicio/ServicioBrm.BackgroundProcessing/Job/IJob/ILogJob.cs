﻿using ServicioBrm.Entities.Entities.Others;

namespace ServicioBrm.BackgroundProcessing.Job.IJob
{
    public interface ILogJob
    {
        void CrearOEditar(AutLog log);
        void GenerarLog(string descripcion, int tipoLog, int userId);
    }
}
