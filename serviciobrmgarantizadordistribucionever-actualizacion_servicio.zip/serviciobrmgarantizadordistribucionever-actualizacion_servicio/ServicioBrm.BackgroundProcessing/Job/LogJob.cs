﻿using ServicioBrm.BackgroundProcessing.Job.IJob;
using ServicioBrm.Entities.Entities.Others;
using ServicioBrm.Services.IServices;

namespace ServicioBrm.BackgroundProcessing.Job
{
    public class LogJob : ILogJob
    {
        private readonly ILogService _logService;

        public LogJob(ILogService logService)
        {
            _logService = logService;
        }

        public void CrearOEditar(AutLog log)
        {
            _logService.CrearOEditar(log);
        }

        public void GenerarLog(string descripcion, int tipoLog, int userId)
        {
            _logService.GenerarLog(descripcion, tipoLog, userId);
        }
    }
}
