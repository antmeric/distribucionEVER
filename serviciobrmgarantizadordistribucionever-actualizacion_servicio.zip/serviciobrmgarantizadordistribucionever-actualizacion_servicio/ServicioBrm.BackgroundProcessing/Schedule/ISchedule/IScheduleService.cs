﻿namespace ServicioBrm.BackgroundProcessing.Schedule.ISchedule
{
    public interface IScheduleService
    {
        void Saludar();
    }
}
