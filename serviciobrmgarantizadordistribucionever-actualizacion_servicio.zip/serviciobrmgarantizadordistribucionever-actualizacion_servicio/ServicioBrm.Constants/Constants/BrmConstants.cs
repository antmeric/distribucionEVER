﻿namespace ServicioBrm.Constants.Constants
{
    public class BrmConstants
    {
        public const short CODIGO_OP_OK = 0;
        public const short CODIGO_OP_ERROR = 1;

        public const string MSJ_OP_OK = "Resultado Correcto";
        public const string MSJ_OP_OK_NO_RESULT = "Sin Resultados";
        public const string MSJ_OP_ERROR = "Error. ";
    }
}
