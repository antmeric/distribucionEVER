﻿namespace ServicioBrm.Constants.Constants
{

    // Clase que almacenará como constantes los distintos permisos que se generarán
    // en la clase de LoginDummy
    public class RoleConstants
    {
        public const string PERMISO_1 = "Permiso_Ejemplo";

    }
}
