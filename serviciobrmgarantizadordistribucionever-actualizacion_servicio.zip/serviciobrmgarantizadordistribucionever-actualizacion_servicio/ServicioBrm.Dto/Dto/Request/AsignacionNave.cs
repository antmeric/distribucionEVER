﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class AsignacionNave
    {
        [DataMember(Order = 1)]
        public List<TotalContenedores> TotalContenedores { get; set; }

        [DataMember(Order = 2)]
        public List<AsignacionPiesTipo> AsignacionPiesTipo { get; set; }


        override

        public string ToString()
        {
            return "[ TOTAL_CONTENEDOR : " + TotalContenedores?.ToString() + ", ASIGNACION_PIES_TIPO : " + AsignacionPiesTipo?.ToString() + "]";
        }
    }
}
