﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class AsignacionPiesTipo
    {
        [DataMember(Order = 1)]
        public string Deposito { get; set; }

        [DataMember(Order = 2)]
        public string PiesTipo { get; set; }

        [DataMember(Order = 3)]
        public int Cantidad { get; set; }

        override

        public string ToString()
        {
            return "[ DEPOSITO : " + Deposito + ", PIESTIPO : " + PiesTipo + ", CANTTIDAD : " + Cantidad + "]";
        }
    }
}
