﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class Contenedor
    {

        [Key]
        [DataMember(Order = 1)]
        public string NumeroContenedor { get; set; }

        [DataMember(Order = 2)]
        public string PiesTipo { get; set; }
        [DataMember(Order = 3)]
        public string Operador { get; set; }
        [DataMember(Order = 4)]
        public string NOR { get; set; }


        override
        public string ToString()
        {
            return "[NUMERO_CONTENEDOR : " + NumeroContenedor + ", PIESTIPO : " + PiesTipo + ", OPERADOR: " + Operador + ", NOR: " + NOR + " ]";
        }
    }
}
