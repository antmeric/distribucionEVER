﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class Peticion
    {

        [Key]
        [DataMember(Order = 1)]
        public DateTime Fecha { get; set; }

        [DataMember(Order = 2)]
        public string Nave { get; set; }
        [DataMember(Order = 3)]
        public string Viaje { get; set; }
        [DataMember(Order = 4)]
        public string RutConsignatario { get; set; }
        [DataMember(Order = 5)]
        public string RutClientePaga { get; set; }
        [DataMember(Order = 6)]
        public string PuertoEmbarque { get; set; }
        [DataMember(Order = 7)]
        public string PuertoDescarga { get; set; }
        [DataMember(Order = 8)]
        public string BL { get; set; }
        [DataMember(Order = 9)]
        public string Contrato { get; set; }
        [DataMember(Order = 10)]
        public string EmisorBL { get; set; }
        [DataMember(Order = 11)]
        public string PuertoOrigen { get; set; }
        [DataMember(Order = 12)]
        public string PuertoDestino { get; set; }
        [DataMember(Order = 13)]
        public List<Contenedor> Contenedor { get; set; }


        override
        public string ToString()
        {
            return "[FECHA : " + Fecha + ", NAVE : " + Nave + ", VIAJE: " + Viaje + ", RUT_CONSIGNATARIO: " + RutConsignatario + "," +
                " RUT_CLIENTE_PAGA : " + RutClientePaga + ", PUERTO_EMBARQUE : " + PuertoEmbarque + ", PUERTO_DESCARGA: " + PuertoDescarga + ", BL: " + BL + "," +
                " CONTRATO: " + Contrato + ", EMISOR_BL: " + EmisorBL + ", PUERTO_ORIGEN: " + PuertoOrigen + ", PUERTO_DESTINO: " + PuertoDestino + "," +
                " CONTENEDOR: " + Contenedor?.ToString() + " ]";
        }
    }
}
