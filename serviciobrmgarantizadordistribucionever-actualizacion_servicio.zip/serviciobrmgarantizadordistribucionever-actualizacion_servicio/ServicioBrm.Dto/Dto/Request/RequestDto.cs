﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class RequestDto
    {
        [DataMember(Order = 1, IsRequired = true)]
        public AsignacionNave AsignacionNave { get; set; }

        [DataMember(Order = 2, IsRequired = true)]
        public Peticion Peticion { get; set; }

        override

        public string ToString()
        {
            return "[ ASIGNACION_NAVE : " + AsignacionNave + ", PETICION : " + Peticion + "]";
        }
    }
}
