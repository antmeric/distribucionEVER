﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ServicioBrm.Dto.Dto.Request
{
    [DataContract, XmlSerializerFormat]
    public class TotalContenedores
    {
        [DataMember(Order = 1)]
        public string PiesTipo { get; set; }

        [DataMember(Order = 2)]
        public int Cantidad { get; set; }


        override

        public string ToString()
        {
            return "[ PIESTIPO : " + PiesTipo + ", CANTTIDAD : " + Cantidad + "]";
        }
    }
}
