﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Response
{
    public class DepositoTolerancia
    {
        public string Deposito { get; set; }

        public int Tolerancia { get; set; }
        public double Cantidad { get; set; }

    }
}
