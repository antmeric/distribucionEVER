﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Response
{
    [DataContract, XmlSerializerFormat]
    public class DistribucionDeposito
    {

        [Key]
        [DataMember, XmlAttribute]
        public string Deposito { get; set; }

        [DataMember, XmlAttribute]
        public string PiesTipo { get; set; }
        [DataMember, XmlAttribute]
        public double PorcentajePedido { get; set; }
        [DataMember, XmlAttribute]
        public double PorcentajeAsignado { get; set; }
        [DataMember, XmlAttribute]
        public int CantidadAsignada { get; set; }


        override
        public string ToString()
        {
            return "[DEPOSITO : " + Deposito + ", PIES_TIPO : " + PiesTipo + ", PORCENTAJE_PEDIDO: " + PorcentajePedido +
                ", PORCENTAJE_ASIGNADO:" + PorcentajeAsignado + ", CANTIDAD_ASIGNADA: " + CantidadAsignada + " ]";
        }
    }
}
