﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Response
{
    [DataContract, XmlSerializerFormat]
    public class ResponseDto
    {

        [Key]
        [DataMember, XmlAttribute]
        public List<DistribucionDeposito> DistribucionDeposito { get; set; }

        [DataMember, XmlAttribute]
        public int Estado { get; set; }
        [DataMember, XmlAttribute]
        public List<Resultado> Resultado { get; set; }


        override
        public string ToString()
        {
            return "[DISTRIBUCION_DEPOSITO : " + DistribucionDeposito?.ToString() + " ESTADO : " + Estado + ", RESULTADO: " + Resultado?.ToString() + " ]";
        }
    }
}
