﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml.Serialization;

namespace ServicioBrm.Dto.Dto.Response
{
    [DataContract, XmlSerializerFormat]
    public class Resultado
    {

        [Key]
        [DataMember, XmlAttribute]
        public string NumeroContenedor { get; set; }

        [DataMember, XmlAttribute]
        public string Deposito { get; set; }
        [DataMember, XmlAttribute]
        public string RegistroCaso4 { get; set; }
        [DataMember, XmlAttribute]
        public string TipoCaso { get; set; }



        override
        public string ToString()
        {
            return "[NUMERO_CONTENEDOR : " + this.NumeroContenedor + ", DEPOSITO : " + this.Deposito + ", REGISTRO_CASO_4: " + this.RegistroCaso4 + ", TIPO_CASO: " +
                this.TipoCaso + " ]";
        }
    }
}
