﻿namespace ServicioBrm.Dto.Dto
{
    public class UsuarioDummyDto
    {
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string NombreCuenta { get; set; }
        public string Branch { get; set; }
        public string Company { get; set; }
    }
}
