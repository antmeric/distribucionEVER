﻿using System;

namespace ServicioBrm.Entities.Entities.Base
{
    public class Base
    {
        public bool AuditNotDeleted { get; set; }

        public DateTime? AuditCreateDate { get; set; }

        public DateTime? AuditLastUpdateDate { get; set; }

        public string AuditUserLastUpdate { get; set; }
    }
}
