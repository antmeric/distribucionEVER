﻿using System;

namespace ServicioBrm.Entities.Entities.Others
{
    public class Auditoria
    {
        public string Creador { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Actualizador { get; set; }
        public DateTime FechaModificacion { get; set; }
        public bool Activo { get; set; }
        public bool Visible { get; set; }
    }
}
