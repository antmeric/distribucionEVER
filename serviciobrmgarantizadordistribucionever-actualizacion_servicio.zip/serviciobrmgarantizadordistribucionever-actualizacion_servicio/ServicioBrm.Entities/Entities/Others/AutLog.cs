﻿using Dapper.Contrib.Extensions;
using System;

namespace ServicioBrm.Entities.Entities.Others
{
    [Table("AutLog")]
    public partial class AutLog
    {
        [Key]
        public int LogId { get; set; }
        public int? LogTypeId { get; set; }
        public string LogDescription { get; set; }
        public DateTime? LogDate { get; set; }
        public int LogUserId { get; set; }
    }
}
