﻿using Dapper.Contrib.Extensions;
namespace ServicioBrm.Entities.Entities.Others
{
    [Table("AutLogTypes")]
    public partial class AutLogTypes
    {
        [Key]
        public int LogTypeId { get; set; }
        public string LogTypesDescription { get; set; }
    }
}
