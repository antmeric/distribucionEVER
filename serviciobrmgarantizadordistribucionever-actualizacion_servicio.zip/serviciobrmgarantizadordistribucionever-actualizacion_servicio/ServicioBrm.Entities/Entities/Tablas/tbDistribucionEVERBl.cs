﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;

namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERBl")]
    public class tbDistribucionEVERBl : Auditoria
    {
        [Key]
        public int Id { get; set; }
        public DateTime FechaVigenciaDesde { get; set; }
        public DateTime FechaVigenciaHasta { get; set; }
        public string Operador { get; set; }
        public string BL { get; set; }
        public string Contenedor { get; set; }
        
        public string PiesTipo { get; set; }
        public string NOR { get; set; }
        public string Deposito { get; set; }
    }
}
