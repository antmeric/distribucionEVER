﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;


namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERClienteEspecial")]
    public class tbDistribucionEVERClienteEspecial : Auditoria
    {
        [Key]
        public int Id { get; set; }
        public DateTime FechaVigenciaDesde { get; set; }
        public DateTime FechaVigenciaHasta { get; set; }
        public string Operador { get; set; }
        public string RutConsignatario { get; set; }
        public string RutClientePaga { get; set; }
        public string PuertoOrigen { get; set; }
        public string PiesTipo { get; set; }
        public string NOR { get; set; }
        public int CuotaCantidad { get; set; }
        public string CuotaDeposito { get; set; }
        
        
    }
}
