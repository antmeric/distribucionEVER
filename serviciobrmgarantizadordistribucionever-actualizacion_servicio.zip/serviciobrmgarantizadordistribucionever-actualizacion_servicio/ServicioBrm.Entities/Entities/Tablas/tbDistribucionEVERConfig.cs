﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;

namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERConfig")]
    public class tbDistribucionEVERConfig
    {
        [Key]
        public int Id { get; set; }                
        public string NombreTabla { get; set; }
        public bool Valor { get; set; }
        public string Descripcion { get; set; }
    }
}
