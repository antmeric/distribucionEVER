﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;

namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERContrato")]
    public class tbDistribucionEVERContrato : Auditoria
    {
        [Key]
        public int Id { get; set; }
        public DateTime FechaVigenciaDesde { get; set; }
        public DateTime FechaVigenciaHasta { get; set; }
        public string Operador { get; set; }
        public string PuertoEmbarque { get; set; }
        public string Contrato { get; set; }
        public string Deposito { get; set; }        
    }
}
