﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;

namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERRecalada")]
    public class tbDistribucionEVERRecalada : Auditoria
    {
        [Key]
        public int Id { get; set; }
        public DateTime FechaVigenciaDesde { get; set; }
        public DateTime FechaVigenciaHasta { get; set; }
        public string Operador { get; set; }
        public string Nave { get; set; }
        public string Viaje { get; set; }
        public string Destino { get; set; }
        public string Descarga { get; set; }       
        public string PiesTipo { get; set; }
        public string NOR { get; set; }
        public string DistribucionDeposito { get; set; }        
        public double DistribucionPorcentaje { get; set; }
        public int DistribucionTolerancia { get; set; }


    }
}
