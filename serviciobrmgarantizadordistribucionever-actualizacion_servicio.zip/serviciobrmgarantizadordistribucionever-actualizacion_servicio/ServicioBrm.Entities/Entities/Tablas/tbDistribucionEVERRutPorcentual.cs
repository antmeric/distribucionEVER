﻿using Dapper.Contrib.Extensions;
using ServicioBrm.Entities.Entities.Others;
using System;

namespace ServicioBrm.Entities.Entities.Tablas
{
    [Table("tbDistribucionEVERRutPorcentual")]
    public class tbDistribucionEVERRutPorcentual : Auditoria
    {
        [Key]
        public int Id { get; set; }
        public DateTime FechaVigenciaDesde { get; set; }
        public DateTime FechaVigenciaHasta { get; set; }
        public string Operador { get; set; }
        public string RutConsignatario { get; set; }
        public string RutClientePaga { get; set; }
        public string PuertoDescarga { get; set; }
        public string PiesTipo { get; set; }
        public string DistribucionDeposito { get; set; }
        public float DistribucionPorcentaje { get; set; }
        public int DistribucionTolerancia { get; set; }        

    }
}
