﻿namespace ServicioBrm.Commons.Connection
{
    public class BrmDb : IConnectionDb
    {
        private string stringConnection;
        public BrmDb(string stringConnection)
        {
            this.stringConnection = stringConnection;
        }

        public override string GetStringConnection()
        {
            return this.stringConnection;
        }
    }
}
