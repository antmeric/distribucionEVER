﻿namespace ServicioBrm.Commons.Connection
{
    public enum ConnectionProviderEnum
    {
        ORACLE,
        SQL_SERVER,
        MYSQL
    }
}
