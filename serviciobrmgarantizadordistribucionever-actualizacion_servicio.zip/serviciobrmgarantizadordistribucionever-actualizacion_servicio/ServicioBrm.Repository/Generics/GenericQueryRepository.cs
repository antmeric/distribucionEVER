﻿using Dapper;
using Dapper.Contrib.Extensions;
using Newtonsoft.Json.Linq;
using ServicioBrm.Commons.Connection;
using ServicioBrm.Repository.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using static ServicioBrm.Commons.Connection.IConnectionDb;

namespace ServicioBrm.Repository.Generics
{
    public class GenericQueryRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class, new()
    {
        #region VARIABLES Y CONSTANTES
        public ConnectionProviderEnum _provider;

        protected string conString;
        public string StateName { get; set; } = "";
        #endregion

        #region Inicializacion
        public GenericQueryRepository(string connectionString, ConnectionProviderEnum provider = ConnectionProviderEnum.SQL_SERVER)
        {
            Initialize(connectionString, provider);
        }

        public GenericQueryRepository(ServiceResolverDb serviceAccessor, string connString, ConnectionProviderEnum provider = ConnectionProviderEnum.SQL_SERVER)
        {
            Initialize(serviceAccessor(connString).GetStringConnection(), provider);
        }

        public void Initialize(string connectionString, ConnectionProviderEnum provider)
        {
            _provider = provider;
            SetConnString(connectionString);
        }

        public void SetConnString(string conString)
        {
            this.conString = conString;
        }
        #endregion

        public virtual async Task<bool> ExecuteCommand(string sql)
        {
            await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<dynamic>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync(sql).ConfigureAwait(false);
            }, GetType().FullName);

            return true;

        }

        public virtual async Task<int> Execute(string sql, object param)
        {
            await ExecutableWrapper.ExecuteWrapperAsynConn<int>(_provider, conString, async (_c) =>
            {
                return await _c.ExecuteAsync(sql, param).ConfigureAwait(false);
            }, GetType().FullName);
            return -1;
        }

        public virtual async Task<bool> ExecuteCommand(string sql, object param)
        {
            await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<dynamic>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync(sql, param).ConfigureAwait(false);
            }, GetType().FullName);

            return true;

        }

        public virtual async Task<IEnumerable<TEntity>> ExecutedQuery(string sql)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<TEntity>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync<TEntity>(sql).ConfigureAwait(false);
            }, GetType().FullName);

            if (!resultDapper.Any())
                return Enumerable.Empty<TEntity>();
            else
                return resultDapper;

        }

        public virtual async Task<IEnumerable<TEntity>> ExecutedQuery(string sql, object param)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<TEntity>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync<TEntity>(sql, param).ConfigureAwait(false);
            }, GetType().FullName);

            if (!resultDapper.Any())
                return Enumerable.Empty<TEntity>();
            else
                return resultDapper;
        }

        public virtual async Task<TEntity> ExecutedQuerySingle(string sql, object param)
        {
            IEnumerable<TEntity> result = await ExecutedQuery(sql, param).ConfigureAwait(false);

            if (result == null || !result.Any())
                return new TEntity();

            return result.FirstOrDefault();

        }
        public virtual async Task<TEntity> ExecutedQuerySingle(string sql)
        {
            IEnumerable<TEntity> result = await ExecutedQuery(sql).ConfigureAwait(false);

            if (result == null || !result.Any())
                return new TEntity();

            return result.FirstOrDefault();

        }

        public virtual async Task<IEnumerable<TEntity>> GetAll()
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<TEntity>>(_provider, conString, async (_c) =>
            {
                IEnumerable<TEntity> result = await _c.GetAllAsync<TEntity>().ConfigureAwait(false);
                return result;
            }, GetType().FullName);

            return resultDapper;

        }

        public async Task<bool> Validate(string sql, object param)
        {
            IEnumerable<TEntity> result = await ExecutedQuery(sql, param).ConfigureAwait(false);

            if (result == null || !result.Any())
                return false;

            return true;

        }

        public virtual async Task<int> CountCommand(string sql)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<int>(_provider, conString, async (_c) =>
            {
                return await _c.ExecuteScalarAsync<int>(sql).ConfigureAwait(false);
            }, GetType().FullName);
            return resultDapper;
        }
        public virtual async Task<int> CountCommand(string sql, object param)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<int>(_provider, conString, async (_c) =>
            {
                return await _c.ExecuteScalarAsync<int>(sql, param).ConfigureAwait(false);
            }, GetType().FullName);
            return resultDapper;
        }

        public async Task<JArray> ExecutedQueryJArray(string sql)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<Object>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync<Object>(sql).ConfigureAwait(false);
            }, GetType().FullName);

            if (!resultDapper.Any())
                return new JArray();
            else
                return JArray.FromObject(resultDapper);

        }

        public async Task<JArray> ExecutedQueryJArray(string sql, object param)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<Object>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync<Object>(sql, param).ConfigureAwait(false);
            }, GetType().FullName);

            if (!resultDapper.Any())
                return new JArray();
            else
                return JArray.FromObject(resultDapper);
        }

        public Task<TEntity> GetById(dynamic Id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteLogico(dynamic Id, string UserLastUpdate)
        {
            throw new NotImplementedException();
        }

        public Task<TEntity> Update(TEntity input)
        {
            throw new NotImplementedException();
        }

        public Task<TEntity> Insert(TEntity input)
        {
            throw new NotImplementedException();
        }

        public virtual async Task<TEntity> InsertOrUpdate(TEntity input)
        {
            if (await this.GetById(input).ConfigureAwait(false) == null)
                //se debe crear
                return await this.Insert(input).ConfigureAwait(false);
            else
                //se debe actualizar
                return await this.Update(input).ConfigureAwait(false);

        }

        public string GetPrimaryKeyValue(TEntity obj)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<TEntity>> ExecutedStoredProcedureObject(string spname, object parameters)
        {
            var resultDapper = await ExecutableWrapper.ExecuteWrapperAsynConn<IEnumerable<TEntity>>(_provider, conString, async (_c) =>
            {
                return await _c.QueryAsync<TEntity>(spname
                                                    , parameters
                                                    , commandType: CommandType.StoredProcedure).ConfigureAwait(false);
            }, GetType().FullName).ConfigureAwait(false);

            return resultDapper;
        }

        public Task<IEnumerable<TEntity>> GetAllByExpression(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<TEntity>> GetAllByExpression(Expression<Func<TEntity, bool>> predicate, int offset, int limit)
        {
            throw new NotImplementedException();
        }

        public Task<int> GetCountByExpression(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }
    }
}
