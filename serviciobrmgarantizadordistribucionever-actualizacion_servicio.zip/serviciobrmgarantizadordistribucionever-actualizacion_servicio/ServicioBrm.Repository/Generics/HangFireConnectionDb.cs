﻿namespace ServicioBrm.Commons.Connection
{
    public class HangFireConnectionDb : IConnectionDb
    {
        private string stringConnection;
        public HangFireConnectionDb(string stringConnection)
        {
            this.stringConnection = stringConnection;
        }

        public override string GetStringConnection()
        {
            return this.stringConnection;
        }
    }
}
