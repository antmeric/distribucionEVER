﻿namespace ServicioBrm.Commons.Connection
{
    public abstract class IConnectionDb
    {
        public delegate IConnectionDb ServiceResolverDb(string key);
        public abstract string GetStringConnection();
    }
}
