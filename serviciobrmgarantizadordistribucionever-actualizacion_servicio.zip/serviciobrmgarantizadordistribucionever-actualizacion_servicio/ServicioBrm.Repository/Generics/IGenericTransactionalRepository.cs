﻿namespace ServicioBrm.Repository.Generics
{
    public interface IGenericTransactionalRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {

    }
}
