﻿using System;

namespace ServicioBrm.Repository.Generics
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
        void SetRepository(Type tipo);
        T GetRepository<T>();
    }
}
