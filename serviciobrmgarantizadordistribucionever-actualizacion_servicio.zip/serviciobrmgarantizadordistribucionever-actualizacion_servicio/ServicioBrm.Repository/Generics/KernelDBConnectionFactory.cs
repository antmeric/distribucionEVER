﻿using System.Data.Common;
using System.Data.SqlClient;

namespace ServicioBrm.Commons.Connection
{
    public class KernelDBConnectionFactory
    {
        public static DbConnection Build(ConnectionProviderEnum connectionProvider, string conn)
        {
            switch (connectionProvider)
            {
                case ConnectionProviderEnum.SQL_SERVER:
                    return new SqlConnection(conn);
                default:
                    return null;
            }
        }

        public static string BuildStringConnection(ConnectionProviderEnum connectionProvider, string conn)
        {
            switch (connectionProvider)
            {
                case ConnectionProviderEnum.SQL_SERVER:
                    return conn;
                case ConnectionProviderEnum.ORACLE:
                    return conn;
                case ConnectionProviderEnum.MYSQL:
                    return conn;
                default:
                    return null;
            }
        }
    }
}
