﻿using ServicioBrm.Entities.Entities.Others;
using ServicioBrm.Repository.Generics;

namespace ServicioBrm.Repository.IRepository
{
    public interface IAutLogTypesRepository : IGenericRepository<AutLogTypes>
    {
    }
}
