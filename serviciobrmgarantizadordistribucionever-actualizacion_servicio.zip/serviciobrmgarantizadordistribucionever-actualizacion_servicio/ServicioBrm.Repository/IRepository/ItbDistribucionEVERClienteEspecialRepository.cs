﻿using ServicioBrm.Entities.Entities.Tablas;
using ServicioBrm.Repository.Generics;

namespace ServicioBrm.Repository.IRepository
{
    public interface ItbDistribucionEVERClienteEspecialRepository : IGenericRepository<tbDistribucionEVERClienteEspecial>
    {
    }
}
