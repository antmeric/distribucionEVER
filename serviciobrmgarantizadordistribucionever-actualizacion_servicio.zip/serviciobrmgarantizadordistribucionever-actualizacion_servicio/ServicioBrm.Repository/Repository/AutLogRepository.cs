﻿using ServicioBrm.Entities.Entities.Others;
using ServicioBrm.Repository.Generics;
using ServicioBrm.Repository.IRepository;
using static ServicioBrm.Commons.Connection.IConnectionDb;

namespace ServicioBrm.Repository.Repository
{
    public class AutLogRepository : GenericRepository<AutLog>, IAutLogRepository
    {
        public AutLogRepository(ServiceResolverDb serviceAccessor) : base(serviceAccessor("BrmDb").GetStringConnection())
        {
        }

    }
}
