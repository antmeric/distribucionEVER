﻿using ServicioBrm.Entities.Entities.Others;
using ServicioBrm.Repository.Generics;
using ServicioBrm.Repository.IRepository;
using System.Data;

namespace ServicioBrm.Repository.Repository
{
    public class AutLogTypesRepository : GenericRepository<AutLogTypes>, IAutLogTypesRepository
    {
        public AutLogTypesRepository(IDbConnection db) : base(db)
        {
        }
    }
}
