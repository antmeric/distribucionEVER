﻿using ServicioBrm.Entities.Entities.Tablas;
using ServicioBrm.Repository.Generics;
using ServicioBrm.Repository.IRepository;
using static ServicioBrm.Commons.Connection.IConnectionDb;

namespace ServicioBrm.Repository.Repository
{
    public class tbDistribucionEVERClienteEspecialRepository : GenericRepository<tbDistribucionEVERClienteEspecial>, ItbDistribucionEVERClienteEspecialRepository
    {
        public tbDistribucionEVERClienteEspecialRepository(ServiceResolverDb serviceAccessor) : base(serviceAccessor("BrmDb").GetStringConnection())
        {
        }
    }
}
