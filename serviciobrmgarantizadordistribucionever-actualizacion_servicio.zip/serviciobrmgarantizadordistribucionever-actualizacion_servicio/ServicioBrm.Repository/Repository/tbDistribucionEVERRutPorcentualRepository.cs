﻿using ServicioBrm.Entities.Entities.Tablas;
using ServicioBrm.Repository.Generics;
using ServicioBrm.Repository.IRepository;
using static ServicioBrm.Commons.Connection.IConnectionDb;

namespace ServicioBrm.Repository.Repository
{
    public class tbDistribucionEVERRutPorcentualRepository : GenericRepository<tbDistribucionEVERRutPorcentual>, ItbDistribucionEVERRutPorcentualRepository
    {
        public tbDistribucionEVERRutPorcentualRepository(ServiceResolverDb serviceAccessor) : base(serviceAccessor("BrmDb").GetStringConnection())
        {
        }
    }
}
