﻿using System;
namespace ServicioBrm.Services.Base
{
    public abstract class BaseService
    {

        public void SetearCamposAuditoria<TEntity>(TEntity entity) where TEntity : ServicioBrm.Entities.Entities.Base.Base
        {
            string user = entity.AuditUserLastUpdate;
            entity.AuditUserLastUpdate = string.IsNullOrEmpty(user) ? "Usuario sin Asignar" : user;
            entity.AuditNotDeleted = true;
            entity.AuditLastUpdateDate = DateTime.Now;
            if (entity.AuditCreateDate == null)
            {
                entity.AuditCreateDate = DateTime.Now;
            }
        }

    }
}
