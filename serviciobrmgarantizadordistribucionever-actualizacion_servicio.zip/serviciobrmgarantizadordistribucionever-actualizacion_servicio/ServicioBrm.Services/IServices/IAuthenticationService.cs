﻿using ServicioBrm.Dto.Dto;

namespace ServicioBrm.Services.IServices
{
    public interface IAuthenticationService
    {
        string obtenerToken(UsuarioDummyDto usuarioDummyDto);
    }
}
