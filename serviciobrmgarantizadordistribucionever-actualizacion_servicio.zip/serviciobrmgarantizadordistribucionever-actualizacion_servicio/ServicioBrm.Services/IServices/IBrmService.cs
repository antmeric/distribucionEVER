﻿using ServicioBrm.Dto.Dto.Request;
using ServicioBrm.Dto.Dto.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServicioBrm.Service.Services.IServices
{
    public interface IBrmService
    {
        Task<ResponseDto> generarTarifa(RequestDto requestDto);

    }
}
