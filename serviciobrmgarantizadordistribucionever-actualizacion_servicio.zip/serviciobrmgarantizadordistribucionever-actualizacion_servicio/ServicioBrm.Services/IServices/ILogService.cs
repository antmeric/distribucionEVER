﻿using ServicioBrm.Entities.Entities.Others;
using System.Threading.Tasks;

namespace ServicioBrm.Services.IServices
{
    public interface ILogService
    {
        Task<AutLog> CrearOEditar(AutLog log);
        Task<AutLog> GenerarLog(string descripcion, int tipoLog, int userId);
    }
}
