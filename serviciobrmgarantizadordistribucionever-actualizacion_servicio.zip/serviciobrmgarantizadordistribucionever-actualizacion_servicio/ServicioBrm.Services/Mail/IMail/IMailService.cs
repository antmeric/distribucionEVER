﻿using ServicioBrm.Dto.Mail;
using System.Threading.Tasks;

namespace ServicioBrm.Services.Mail.IMail
{
    public interface IMailService
    {
        Task EnviarMailAsync(MailDto email);
    }
}
