﻿using ServicioBrm.Dto.Mail.Settings;

namespace ServicioBrm.Services.Mail.IMail
{
    public interface IMailSettingsContainer
    {
        MailSettings GetMailSettings();
    }
}
