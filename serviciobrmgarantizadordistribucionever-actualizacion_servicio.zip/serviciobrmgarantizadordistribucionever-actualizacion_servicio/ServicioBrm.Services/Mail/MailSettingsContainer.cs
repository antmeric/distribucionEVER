﻿using ServicioBrm.Dto.Mail.Settings;
using ServicioBrm.Services.Mail.IMail;

namespace ServicioBrm.Services.Mail
{
    public class MailSettingsContainer : IMailSettingsContainer
    {

        private readonly MailSettings mailSettings;

        public MailSettingsContainer(MailSettings mailSettings)
        {
            this.mailSettings = mailSettings;
        }

        public MailSettings GetMailSettings()
        {
            return mailSettings;
        }
    }
}
