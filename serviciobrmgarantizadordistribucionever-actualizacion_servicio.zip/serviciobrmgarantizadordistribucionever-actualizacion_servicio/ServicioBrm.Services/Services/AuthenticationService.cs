﻿using Microsoft.IdentityModel.Tokens;
using ServicioBrm.Dto.Dto;
using ServicioBrm.Services.IServices;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ServicioBrm.Services.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        public string obtenerToken(UsuarioDummyDto usuarioDummyDto)
        {
            List<Claim> claims = obtenerClaimsPorTipoCuenta(usuarioDummyDto);
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345"));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
            var tokeOptions = new JwtSecurityToken(
                issuer: "http://ultrakernel.net",
                audience: "http://localhost:5000",
                claims: claims,
                expires: DateTime.Now.AddMinutes(100),
                signingCredentials: signinCredentials
            );
            return new JwtSecurityTokenHandler().WriteToken(tokeOptions);
        }

        private List<Claim> obtenerClaimsPorTipoCuenta(UsuarioDummyDto usuarioDummyDto)
        {
            List<Claim> claims = new List<Claim>()
            {
                new Claim("UserName", usuarioDummyDto.UserName),
                new Claim("UserEmail", usuarioDummyDto.UserEmail),
                new Claim("NombreCuenta", usuarioDummyDto.NombreCuenta),
                new Claim("Company", usuarioDummyDto.Company)
            };
            // Acá deben agregar los permisos que quieran probar con sus perfiles
            claims.Add(new Claim(ClaimTypes.Role, "PARE_PARE_VERSINTRANS"));
            claims.Add(new Claim(ClaimTypes.Role, "VISO_VIST_MINERA_SENTINELA"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_USUA_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_USUA_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_USUA_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_USUA_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_EMPR_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SUCU_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERF_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERM_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERM_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERM_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_PERM_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SIST_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SIST_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SIST_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_SIST_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_GRUP_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_GRUP_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_GRUP_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_GRUP_VER"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_MODU_CREAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_MODU_EDITAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_MODU_ELIMINAR"));
            claims.Add(new Claim(ClaimTypes.Role, "KERK_MODU_VER"));
            return claims;
        }

    }
}
