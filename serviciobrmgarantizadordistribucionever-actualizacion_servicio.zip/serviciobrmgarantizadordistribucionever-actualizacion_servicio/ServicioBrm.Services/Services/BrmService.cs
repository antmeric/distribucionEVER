﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Bcpg;
using ServicioBrm.Constants.Constants;
using ServicioBrm.Dto.Dto.Request;
using ServicioBrm.Dto.Dto.Response;
using ServicioBrm.Repository.IRepository;
using ServicioBrm.Services.Services;
using ServicioBrm.Entities.Entities.Tablas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using System.Resources;



namespace ServicioBrm.Service.Services
{
    public class BrmService : IServices.IBrmService
    {
        private LogService loggerDb;
        private readonly ILogger _logger;
        private ItbDistribucionEVERRutRepository _rutRepository;
        private ItbDistribucionEVERBlRepository _blRepository;
        private ItbDistribucionEVERRecaladaRepository _recaladaRepository;
        private ItbDistribucionEVERClienteEspecialRepository _clienteEspecialRepository;
        private ItbDistribucionEVERContratoRepository _contratoRepository;
        private ItbDistribucionEVERRutPorcentualRepository _rutPorcentualRepository;
        private ItbDistribucionEVERConfigRepository _configRepository;


        public BrmService(IAutLogRepository logRepository,
                                ILogger<BrmService> logger, ItbDistribucionEVERRutRepository RutRepository, ItbDistribucionEVERBlRepository BLRepository, ItbDistribucionEVERRecaladaRepository recaladaRepository,
            ItbDistribucionEVERClienteEspecialRepository clienteEspecialRepository, ItbDistribucionEVERContratoRepository contratoRepository, ItbDistribucionEVERRutPorcentualRepository rutPorcentualRepository,
            ItbDistribucionEVERConfigRepository configRepository)
        {
            loggerDb = new LogService(logRepository);
            _logger = logger;
            _rutRepository = RutRepository;
            _blRepository = BLRepository;
            _recaladaRepository = recaladaRepository;
            _clienteEspecialRepository = clienteEspecialRepository;
            _contratoRepository = contratoRepository;
            _rutPorcentualRepository = rutPorcentualRepository;
            _configRepository = configRepository;
        }

        public async Task<ResponseDto> generarTarifa(RequestDto requestDto)
        {
            try
            {
                //Inicializo responses
                ResponseDto response = new ResponseDto(); //response que contiene resultado, estado y distribucion con sus respectivas listas                        
                                                          // Inicializo las listas para almacenar resultados posteriores

                int codigoSalida = BrmConstants.CODIGO_OP_OK;

                List<DistribucionDeposito> distribucionList = new List<DistribucionDeposito>();
                List<DistribucionDeposito> distribucionRecaladaList = new List<DistribucionDeposito>();
                List<DistribucionDeposito> distribucionClienteList = new List<DistribucionDeposito>();
                List<DistribucionDeposito> distribucionPorcentualList = new List<DistribucionDeposito>();

                // Inicializo REQUEST

                Peticion peticion = new Peticion();
                peticion = requestDto.Peticion;
                List<Resultado> asignacionDepositoList = new List<Resultado>();
                List<string> depositos = new List<string>();


                int i = 0;
                int n = 0;
                int p = 0;
                DepositoPiesTipo depositoElegido = new DepositoPiesTipo();

                List<DepositoPiesTipo> depositosCantidades = new List<DepositoPiesTipo>();
                bool setearDeposito = true;
                bool entroFor = true;



                for (int l = 0; l < peticion.Contenedor.Count(); l++)
                {
                    Contenedor cont = new Contenedor();
                    cont = peticion.Contenedor[l];
                    Resultado resultado = new Resultado();

                    // TRANSFORMAR NOR A FALSE O TRUE
                    if (cont.NOR == "0")
                    {
                        cont.NOR = "FALSE";
                    }
                    else if (cont.NOR == "1")
                    {
                        cont.NOR = "TRUE";
                    }

                    // FLUJO 1: BUSCAR EN TABLA RUT
                    StringBuilder queryRut = generarQueryRut();


                    var dictionaryRut = new Dictionary<string, object>();
                    generarParametro(dictionaryRut, "@fecha", peticion.Fecha);
                    generarParametro(dictionaryRut, "@operador", cont.Operador);
                    generarParametro(dictionaryRut, "@rutConsignatario", peticion.RutConsignatario);
                    generarParametro(dictionaryRut, "@rutClientePaga", peticion.RutClientePaga);
                    generarParametro(dictionaryRut, "@puertoDescarga", peticion.PuertoDescarga);
                    generarParametro(dictionaryRut, "@bl", peticion.BL);
                    generarParametro(dictionaryRut, "@puertoEmbarque", peticion.PuertoEmbarque);
                    generarParametro(dictionaryRut, "@contenedor", cont.NumeroContenedor);
                    generarParametro(dictionaryRut, "@piesTipo", cont.PiesTipo);
                    generarParametro(dictionaryRut, "@nor", cont.NOR);

                    var reglaRut = (await _rutRepository.ExecutedQuery(queryRut.ToString(), dictionaryRut)).ToList();
                    //REGLARut NO ESTÁ VACÍO Y ES LISTA TIENE ALGUN RESULTADO?
                    if (reglaRut != null && reglaRut.Count() > 0)
                    {
                        var ultimaReglaRut = reglaRut.Last();
                        resultado.NumeroContenedor = cont.NumeroContenedor;
                        resultado.Deposito = ultimaReglaRut.Deposito;
                        resultado.RegistroCaso4 = "-----";
                        resultado.TipoCaso = "POR RUT - ID: " + ultimaReglaRut.Id;
                        asignacionDepositoList.Add(resultado);
                    }
                    else
                    {
                        //NO ENCUENTRA; FLUJO 2: BUSCAR TABLA BL
                        StringBuilder queryBL = generarQueryBL();


                        var dictionaryBL = new Dictionary<string, object>();
                        generarParametro(dictionaryBL, "@fecha", peticion.Fecha);
                        generarParametro(dictionaryBL, "@operador", cont.Operador);
                        generarParametro(dictionaryBL, "@bl", peticion.BL);
                        generarParametro(dictionaryBL, "@contenedor", cont.NumeroContenedor);
                        generarParametro(dictionaryBL, "@piesTipo", cont.PiesTipo);
                        generarParametro(dictionaryBL, "@nor", cont.NOR);

                        var reglaBL = (await _blRepository.ExecutedQuery(queryBL.ToString(), dictionaryBL)).ToList();

                        if (reglaBL != null && reglaBL.Count() > 0)
                        {
                            var ultimaReglaBL = reglaBL.Last();
                            resultado.NumeroContenedor = cont.NumeroContenedor;
                            resultado.Deposito = ultimaReglaBL.Deposito;
                            resultado.RegistroCaso4 = "-----";
                            resultado.TipoCaso = "POR BL - ID: " + ultimaReglaBL.Id;
                            asignacionDepositoList.Add(resultado);
                        }
                        else
                        {
                            //NO ENCUENTRA; FLUJO 3: BUSCAR TABLA CONTRATO
                            StringBuilder queryContrato = generarQueryContrato();


                            var dictionaryContrato = new Dictionary<string, object>();
                            generarParametro(dictionaryContrato, "@fecha", peticion.Fecha);
                            generarParametro(dictionaryContrato, "@operador", cont.Operador);
                            generarParametro(dictionaryContrato, "@puertoEmbarque", peticion.PuertoEmbarque);
                            generarParametro(dictionaryContrato, "@contrato", peticion.Contrato);

                            var reglaContrato = (await _contratoRepository.ExecutedQuery(queryContrato.ToString(), dictionaryContrato)).ToList();

                            if (reglaContrato != null && reglaContrato.Count > 0)
                            {

                                var ultimaReglaContrato = reglaContrato.Last();
                                resultado.NumeroContenedor = cont.NumeroContenedor;
                                resultado.Deposito = ultimaReglaContrato.Deposito;
                                resultado.RegistroCaso4 = "---- - ";
                                resultado.TipoCaso = "POR CONTRATO - ID: " + ultimaReglaContrato.Id;
                                asignacionDepositoList.Add(resultado);

                            }
                            else
                            {
                                //NO ENCUENTRA; FLUJO 4: BUSCAR TABLA PORCENTUAL
                                //INSTANCIO LISTA DEL REQUEST
                                TotalContenedores totalContenedores = new TotalContenedores();
                                AsignacionNave asignacionNave = new AsignacionNave();
                                totalContenedores = requestDto.AsignacionNave.TotalContenedores[0];
                                DistribucionDeposito distribucion = new DistribucionDeposito();
                                int cant = 0;
                                StringBuilder queryPorcentual = generarQueryPorcentual();
                                var dictionaryPorcentutal = new Dictionary<string, object>();
                                generarParametro(dictionaryPorcentutal, "@fecha", peticion.Fecha);
                                generarParametro(dictionaryPorcentutal, "@operador", cont.Operador);
                                generarParametro(dictionaryPorcentutal, "@rutConsignatario", peticion.RutConsignatario);
                                generarParametro(dictionaryPorcentutal, "@rutClientePaga", peticion.RutClientePaga);
                                generarParametro(dictionaryPorcentutal, "@puertoDescarga", peticion.PuertoDescarga);
                                generarParametro(dictionaryPorcentutal, "@piesTipo", cont.PiesTipo);

                                var reglaPorcentual = (await _rutPorcentualRepository.ExecutedQuery(queryPorcentual.ToString(), dictionaryPorcentutal)).ToList();

                                if (reglaPorcentual != null && reglaPorcentual.Count > 0)
                                {

                                    var ultimaReglaPorcentual = reglaPorcentual.Last();



                                    var c = (await _configRepository.GetAllByExpression(x => x.NombreTabla == "tbDistribucionEVERRutPorcentual"));

                                    var config = c.FirstOrDefault();
                                    bool flag = config.Valor;

                                    if (flag)
                                    {
                                        // PRIMER RESPONSE
                                        reglaPorcentual.ForEach(r =>
                                        {
                                            // Check if a distribution with the same Deposito AND PiesTipo already exists in distribucionList
                                            if (!distribucionList.Any(d => d.Deposito == r.DistribucionDeposito && d.PiesTipo == r.PiesTipo))
                                            {
                                                DistribucionDeposito distribucion = new DistribucionDeposito();
                                                distribucion.Deposito = r.DistribucionDeposito;
                                                distribucion.PiesTipo = r.PiesTipo;
                                                distribucion.PorcentajePedido = r.DistribucionPorcentaje;

                                                requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                {
                                                    if (a.Deposito == r.DistribucionDeposito)
                                                    {
                                                        //se encuentra el deposito
                                                        cant = a.Cantidad;
                                                    }
                                                });

                                                if (totalContenedores.Cantidad != 0)
                                                {
                                                    double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                    distribucion.PorcentajeAsignado = porcAsig;
                                                }
                                                else
                                                {
                                                    distribucion.PorcentajeAsignado = 0;
                                                }

                                                distribucion.CantidadAsignada = cant;
                                                distribucionList.Add(distribucion);
                                                distribucionPorcentualList.Add(distribucion);
                                                n++;
                                            }

                                        });
                                        // SEGUNDO RESPONSE                                    
                                        // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES
                                        // Obtiene la lista de depósitos disponibles
                                        if (setearDeposito)
                                        {
                                            // SEGUNDO RESPONSE                                    
                                            // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES


                                            // Crear una lista de tuplas (Deposito, Porcentaje, PiesTipo) para la selección aleatoria ponderada
                                            var distribucionesParaSeleccion = distribucionPorcentualList
                                                     .Where(d => d.PiesTipo == cont.PiesTipo)    // Filtra según el piesTipo                                                        
                                                     .Select(d => (d.Deposito, d.PorcentajePedido, d.PiesTipo))
                                                     .ToList();
                                            var depositosPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();
                                            // Seleccionar un depósito aleatorio basado en los porcentajes
                                            var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count(d => d.PiesTipo == cont.PiesTipo));

                                            // Obtener ID para mostrar en pantalla
                                            var takeId = reglaPorcentual.First(r => r.DistribucionDeposito == depositoElegido2.Deposito);
                                            int id = takeId.Id;

                                            resultado.NumeroContenedor = cont.NumeroContenedor;
                                            resultado.Deposito = depositoElegido2.Deposito;
                                            resultado.RegistroCaso4 = "------ ";
                                            resultado.TipoCaso = "POR RUT PORCENTUAL: - ID: " + id;
                                            asignacionDepositoList.Add(resultado);

                                            if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                            {
                                                int m = l;
                                                if (peticion.Contenedor.Count() > m + 1)
                                                {
                                                    if (peticion.Contenedor[m + 1] != null)
                                                    {
                                                        Resultado resultado2 = new Resultado();
                                                        resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                        resultado2.Deposito = depositoElegido2.Deposito;
                                                        resultado2.RegistroCaso4 = "------ ";
                                                        resultado2.TipoCaso = "POR RUT PORCENTUAL - ID: " + ultimaReglaPorcentual.Id;
                                                        asignacionDepositoList.Add(resultado2);
                                                        l++;
                                                    }
                                                }

                                            }
                                        }
                                    }
                                    else
                                    {


                                        // SI ES LA PRI7MERA VEZ K PASA POR ESTE IF:
                                        if (n == 0)
                                        {
                                            // PRIMER RESPONSE
                                            reglaPorcentual.ForEach(r =>
                                            {
                                                DistribucionDeposito distribucion = new DistribucionDeposito();
                                                distribucion.Deposito = r.DistribucionDeposito;
                                                distribucion.PiesTipo = r.PiesTipo;
                                                distribucion.PorcentajePedido = r.DistribucionPorcentaje;
                                                requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                {
                                                    if (a.Deposito == r.DistribucionDeposito)
                                                    {
                                                        //se encuentra el deposito
                                                        cant = a.Cantidad;
                                                    }
                                                });
                                                double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                distribucion.PorcentajeAsignado = porcAsig;
                                                distribucion.CantidadAsignada = cant;
                                                distribucionList.Add(distribucion);
                                                n++;

                                            });
                                        }
                                        // SEGUNDO RESPONSE                                    
                                        // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES
                                        // Obtiene la lista de depósitos disponibles
                                        if (setearDeposito)
                                        {
                                            // SEGUNDO RESPONSE                                    
                                            // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES


                                            // Crear una lista de tuplas (Deposito, Porcentaje) para la selección aleatoria ponderada
                                            var distribucionesParaSeleccion = distribucionList.Select(d => (d.Deposito, d.PorcentajePedido, d.PiesTipo)).ToList();
                                            var depositosPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();

                                            // Seleccionar un depósito aleatorio basado en los porcentajes
                                            var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count());
                                            // Seleccionar un depósito aleatorio basado en los porcentajes


                                         

                                            resultado.NumeroContenedor = cont.NumeroContenedor;
                                            resultado.Deposito = depositoElegido2.Deposito;
                                            resultado.RegistroCaso4 = "------ ";
                                            resultado.TipoCaso = "POR RUT PORCENTUAL";
                                            asignacionDepositoList.Add(resultado);

                                            if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                            {
                                                int m = l;
                                                if (peticion.Contenedor.Count() > m + 1)
                                                {
                                                    if (peticion.Contenedor[m + 1] != null)
                                                    {
                                                        Resultado resultado2 = new Resultado();
                                                        resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                        resultado2.Deposito = depositoElegido2.Deposito;
                                                        resultado2.RegistroCaso4 = "------ ";
                                                        resultado2.TipoCaso = "POR RUT PORCENTUAL";
                                                        asignacionDepositoList.Add(resultado2);
                                                        l++;
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    StringBuilder queryRecalada = generarQueryRecalada();


                                    var dictionaryRecalada = new Dictionary<string, object>();
                                    generarParametro(dictionaryRecalada, "@fecha", peticion.Fecha);
                                    generarParametro(dictionaryRecalada, "@operador", cont.Operador);
                                    generarParametro(dictionaryRecalada, "@nave", peticion.Nave);
                                    generarParametro(dictionaryRecalada, "@viaje", peticion.Viaje);
                                    generarParametro(dictionaryRecalada, "@destino", peticion.PuertoDestino);
                                    generarParametro(dictionaryRecalada, "@descarga", peticion.PuertoDescarga);
                                    generarParametro(dictionaryRecalada, "@piesTipo", cont.PiesTipo);
                                    generarParametro(dictionaryRecalada, "@nor", cont.NOR);

                                    var reglaRecalada = (await _recaladaRepository.ExecutedQuery(queryRecalada.ToString(), dictionaryRecalada)).ToList();

                                    if (reglaRecalada != null && reglaRecalada.Count > 0)
                                    {

                                        // Lista para usar sólo las reglas más específicas
                                        List<tbDistribucionEVERRecalada> list = new List<tbDistribucionEVERRecalada>();

                                        tbDistribucionEVERRecalada recalada = new tbDistribucionEVERRecalada();
                                        recalada = reglaRecalada.First();
                                        // Cuenta la cantidad de "ALL" en la primera regla y la almacena en la variable
                                        int countActual = countAllOcurrencesRecalada(recalada);
                                        // Recorro cada regla
                                        reglaRecalada.ForEach(e =>
                                        {
                                            // Cuenta la cantidad de "ALL" en la regla que itera
                                            int countNuevo = countAllOcurrencesRecalada(e);
                                            // Si la cantidad es igual a la anterior, almacena la regla en una lista
                                            if (countNuevo == countActual)
                                            {
                                                list.Add(e);                                                
                                            }
                                            // Si la cantidad de ALL de la regla iterada es menor a la cantidad de ALL de la regla iterada ANTERIOR
                                            else if (countNuevo < countActual)
                                            {
                                                // Limpia la lista con las reglas guardadas anteriormente
                                                list.Clear();
                                                // Añade la nueva regla a la lista
                                                list.Add(e);
                                                // La cantidad de ALL de la regla ANTERIOR es igual a la cantidad de ALL de la regla iterada (para el siguiente)
                                                countActual = countNuevo;
                                            }
                                        });
                                        var z = (await _configRepository.GetAllByExpression(x => x.NombreTabla == "tbDistribucionEVERRecalada"));

                                        var config = z.FirstOrDefault();
                                        bool flag = config.Valor;

                                        if (flag)
                                        {
                                            // PRIMER RESPONSE
                                            // Itero sobre la lista que cree con las reglas específicas almacenadas
                                            list.ForEach(r =>
                                            {
                                                // Check if a distribution with the same Deposito AND PiesTipo already exists in distribucionList
                                                if (!distribucionList.Any(d => d.Deposito == r.DistribucionDeposito && d.PiesTipo == r.PiesTipo))
                                                {
                                                    DistribucionDeposito distribucion = new DistribucionDeposito();
                                                    distribucion.Deposito = r.DistribucionDeposito;
                                                    distribucion.PiesTipo = r.PiesTipo;
                                                    distribucion.PorcentajePedido = r.DistribucionPorcentaje;

                                                    requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                    {
                                                        if (a.Deposito == r.DistribucionDeposito)
                                                        {
                                                            //se encuentra el deposito
                                                            cant = a.Cantidad;
                                                        }
                                                    });

                                                    if (totalContenedores.Cantidad != 0)
                                                    {
                                                        double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                        distribucion.PorcentajeAsignado = porcAsig;
                                                    }
                                                    else
                                                    {
                                                        distribucion.PorcentajeAsignado = 0;
                                                    }

                                                    distribucion.CantidadAsignada = cant;
                                                    distribucionList.Add(distribucion);
                                                    distribucionRecaladaList.Add(distribucion);
                                                    n++;
                                                }

                                            });
                                            if (setearDeposito)
                                            {

                                                // SEGUNDO RESPONSE                                    
                                                // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES

                                                // Crear una lista de tuplas (Deposito, Porcentaje) para la selección aleatoria ponderada                                            
                                                var distribucionesParaSeleccion = distribucionRecaladaList
                                                    .Where(d => d.PiesTipo == cont.PiesTipo)    // Filtra según el piesTipo                                                        
                                                    .Select(d => (d.Deposito, d.PorcentajePedido, d.PiesTipo))
                                                    .ToList();
                                                // Condición para calcular nuevo porcentaje
                                                if (depositos.Count() > 0 && depositos != null)
                                                {

                                                    for (int c = 0; c < distribucionesParaSeleccion.Count; c++)
                                                    {
                                                        var dps = distribucionesParaSeleccion[c];
                                                        // Contar las ocurrencias de dps.Deposito en la lista depositos
                                                        int conteo = depositos.Count(d => d == dps.Deposito);
                                                        // Regla de 3 simples para sacar la cantidad total en base al %
                                                        double total = (dps.PorcentajePedido * peticion.Contenedor.Count()) / 100;
                                                        //int totalEntero = (int)Math.Round(total, MidpointRounding.AwayFromZero);
                                                        int totalEntero = (int)Math.Ceiling(total); // AKI

                                                        p = totalEntero - conteo;

                                                        if (totalEntero > 0)
                                                        {
                                                            dps.PorcentajePedido = (p * dps.PorcentajePedido) / totalEntero;
                                                            distribucionesParaSeleccion[c] = dps; // Actualiza el elemento original
                                                        }

                                                    }
                                                }

                                                var depositosPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();

                                                // Seleccionar un depósito aleatorio basado en los porcentajes
                                                var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count(d => d.PiesTipo == cont.PiesTipo));

                                                // Obtener ID para mostrar en pantalla
                                                var takeId = list.First(r => r.DistribucionDeposito == depositoElegido2.Deposito);
                                                int id = takeId.Id;

                                                // Añado el deposito elegido a una lista de strings para calcular el nuevo porcentaje
                                                depositos.Add(depositoElegido2.Deposito);


                                                resultado.NumeroContenedor = cont.NumeroContenedor;
                                                resultado.Deposito = depositoElegido2.Deposito;
                                                resultado.RegistroCaso4 = "------ ";
                                                resultado.TipoCaso = "POR RECALADA - ID: " + id;
                                                asignacionDepositoList.Add(resultado);

                                                if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                                {
                                                    int m = l;
                                                    if (peticion.Contenedor.Count() > m + 1)
                                                    {
                                                        if (peticion.Contenedor[m + 1] != null)
                                                        {
                                                            Resultado resultado2 = new Resultado();
                                                            resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                            resultado2.Deposito = depositoElegido2.Deposito;
                                                            resultado2.RegistroCaso4 = "------ ";
                                                            resultado2.TipoCaso = "POR RECALADA - ID: " + id;
                                                            asignacionDepositoList.Add(resultado2);
                                                            l++;

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (n == 0)
                                            {
                                                // PRIMER RESPONSE
                                                // Itero sobre la lista que cree con las reglas específicas almacenadas
                                                list.ForEach(r =>
                                                {
                                                    DistribucionDeposito distribucion = new DistribucionDeposito();
                                                    distribucion.Deposito = r.DistribucionDeposito;
                                                    distribucion.PiesTipo = r.PiesTipo;
                                                    distribucion.PorcentajePedido = r.DistribucionPorcentaje;
                                                    requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                    {
                                                        if (a.Deposito == r.DistribucionDeposito)
                                                        {
                                                            //se encuentra el deposito
                                                            cant = a.Cantidad;
                                                        }
                                                    });
                                                    double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                    distribucion.PorcentajeAsignado = porcAsig;
                                                    distribucion.CantidadAsignada = cant;
                                                    distribucionList.Add(distribucion);
                                                    n++;

                                                });
                                            }
                                            if (setearDeposito)
                                            {

                                                // SEGUNDO RESPONSE                                    
                                                // ASIGNAR DEPOSITO AL AZAR BASADO EN SUS PORCENTAJES

                                                // Crear una lista de tuplas (Deposito, Porcentaje) para la selección aleatoria ponderada
                                                var distribucionesParaSeleccion = distribucionList.Select(d => (d.Deposito, d.PorcentajePedido, d.PiesTipo)).ToList();
                                                // Condición para calcular nuevo porcentaje
                                                if (depositos.Count() > 0 && depositos != null)
                                                {

                                                    for (int c = 0; c < distribucionesParaSeleccion.Count; c++)
                                                    {
                                                        var dps = distribucionesParaSeleccion[c];
                                                        // Contar las ocurrencias de dps.Deposito en la lista depositos
                                                        int conteo = depositos.Count(d => d == dps.Deposito);
                                                        // Regla de 3 simples para sacar la cantidad total en base al %
                                                        double total = (dps.PorcentajePedido * peticion.Contenedor.Count()) / 100;
                                                        //int totalEntero = (int)Math.Round(total, MidpointRounding.AwayFromZero);
                                                        int totalEntero = (int)Math.Ceiling(total); // AKI

                                                        p = totalEntero - conteo;

                                                        if (totalEntero > 0)
                                                        {
                                                            dps.PorcentajePedido = (p * dps.PorcentajePedido) / totalEntero;
                                                            distribucionesParaSeleccion[c] = dps; // Actualiza el elemento original
                                                        }

                                                    }
                                                }

                                                var depositosPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();

                                                // Seleccionar un depósito aleatorio basado en los porcentajes
                                                var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count());
                                               
                                                // Añado el deposito elegido a una lista de strings para calcular el nuevo porcentaje
                                                depositos.Add(depositoElegido2.Deposito);


                                                resultado.NumeroContenedor = cont.NumeroContenedor;
                                                resultado.Deposito = depositoElegido2.Deposito;
                                                resultado.RegistroCaso4 = "------ ";
                                                resultado.TipoCaso = "POR RECALADA ";
                                                asignacionDepositoList.Add(resultado);

                                                if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                                {
                                                    int m = l;
                                                    if (peticion.Contenedor.Count() > m + 1)
                                                    {
                                                        if (peticion.Contenedor[m + 1] != null)
                                                        {
                                                            Resultado resultado2 = new Resultado();
                                                            resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                            resultado2.Deposito = depositoElegido2.Deposito;
                                                            resultado2.RegistroCaso4 = "------ ";
                                                            resultado2.TipoCaso = "POR RECALADA  ";
                                                            asignacionDepositoList.Add(resultado2);
                                                            l++;

                                                        }
                                                    }
                                                }
                                            }

                                        }
                                    }
                                    else
                                    {
                                        StringBuilder queryClienteEspecial = generarQueryClienteEspecial();


                                        var dictionaryClienteEspecial = new Dictionary<string, object>();
                                        generarParametro(dictionaryClienteEspecial, "@fecha", peticion.Fecha);
                                        generarParametro(dictionaryClienteEspecial, "@operador", cont.Operador);
                                        generarParametro(dictionaryClienteEspecial, "@rutConsignatario", peticion.RutConsignatario);
                                        generarParametro(dictionaryClienteEspecial, "@rutClientePaga", peticion.RutClientePaga);
                                        generarParametro(dictionaryClienteEspecial, "@puertoOrigen", peticion.PuertoOrigen);
                                        generarParametro(dictionaryClienteEspecial, "@piesTipo", cont.PiesTipo);
                                        generarParametro(dictionaryClienteEspecial, "@nor", cont.NOR);

                                        var reglaClienteEspecial = (await _clienteEspecialRepository.ExecutedQuery(queryClienteEspecial.ToString(), dictionaryClienteEspecial)).ToList();

                                        if (reglaClienteEspecial != null && reglaClienteEspecial.Count > 0)
                                        {

                                            var ultimaReglaClienteEspecial = reglaClienteEspecial.Last();

                                            var z = (await _configRepository.GetAllByExpression(x => x.NombreTabla == "tbDistribucionEVERClienteEspecial"));

                                            var config = z.FirstOrDefault();
                                            bool flag = config.Valor;

                                            if (flag)
                                            {
                                                // PRIMER RESPONSE
                                                reglaClienteEspecial.ForEach(r =>
                                                {
                                                    // Check if a distribution with the same Deposito AND PiesTipo already exists in distribucionList
                                                    if (!distribucionList.Any(d => d.Deposito == r.CuotaDeposito && d.PiesTipo == r.PiesTipo))
                                                    {
                                                        DistribucionDeposito distribucion = new DistribucionDeposito();
                                                        distribucion.Deposito = r.CuotaDeposito;
                                                        distribucion.PiesTipo = r.PiesTipo;
                                                        distribucion.PorcentajePedido = 0;

                                                        requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                        {
                                                            if (a.Deposito == r.CuotaDeposito)
                                                            {
                                                                //se encuentra el deposito
                                                                cant = a.Cantidad;
                                                            }
                                                        });

                                                        if (totalContenedores.Cantidad != 0)
                                                        {
                                                            double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                            distribucion.PorcentajeAsignado = porcAsig;
                                                        }
                                                        else
                                                        {
                                                            distribucion.PorcentajeAsignado = 0;
                                                        }

                                                        distribucion.CantidadAsignada = cant;
                                                        distribucionList.Add(distribucion);
                                                        distribucionClienteList.Add(distribucion);
                                                        n++;
                                                    }

                                                });
                                                if (setearDeposito)
                                                {
                                                    // Crear una lista de tuplas (Deposito, Porcentaje) para la selección aleatoria ponderada
                                                    var distribucionesParaSeleccion = distribucionClienteList
                                                    .Where(d => d.PiesTipo == cont.PiesTipo)    // Filtra según el piesTipo                                                        
                                                    .Select(d => (d.Deposito, d.PorcentajePedido, d.PiesTipo))
                                                    .ToList();
                                                    var depositoPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();
                                                    // Seleccionar un depósito aleatorio basado en los porcentajes
                                                    var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count(d => d.PiesTipo == cont.PiesTipo));

                                                    // Obtener ID para mostrar en pantalla
                                                    var takeId = reglaClienteEspecial.First(r => r.CuotaDeposito == depositoElegido2.Deposito);
                                                    int id = takeId.Id;

                                                    resultado.NumeroContenedor = cont.NumeroContenedor;
                                                    resultado.Deposito = depositoElegido2.Deposito;
                                                    resultado.RegistroCaso4 = "------ ";
                                                    resultado.TipoCaso = "POR CLIENTE ESPECIAL - ID: " + id;
                                                    asignacionDepositoList.Add(resultado);

                                                    if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                                    {
                                                        int m = l;
                                                        if (peticion.Contenedor.Count() > m + 1)
                                                        {
                                                            if (peticion.Contenedor[m + 1] != null)
                                                            {
                                                                Resultado resultado2 = new Resultado();
                                                                resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                                resultado2.Deposito = depositoElegido2.Deposito;
                                                                resultado2.RegistroCaso4 = "------ ";
                                                                resultado2.TipoCaso = "POR CLIENTE ESPECIAL - ID: " + id;
                                                                asignacionDepositoList.Add(resultado2);
                                                                l++;
                                                            }
                                                        }

                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (n == 0)
                                                {
                                                    // PRIMER RESPONSE
                                                    reglaClienteEspecial.ForEach(r =>
                                                    {
                                                        DistribucionDeposito distribucion = new DistribucionDeposito();
                                                        distribucion.Deposito = r.CuotaDeposito;
                                                        distribucion.PiesTipo = r.PiesTipo;
                                                        distribucion.PorcentajePedido = 0;
                                                        requestDto.AsignacionNave.AsignacionPiesTipo.ForEach(a =>
                                                        {
                                                            if (a.Deposito == r.CuotaDeposito)
                                                            {
                                                                //se encuentra el deposito
                                                                cant = a.Cantidad;
                                                            }
                                                        });
                                                        double porcAsig = ((cant * 100) / totalContenedores.Cantidad);
                                                        distribucion.PorcentajeAsignado = porcAsig;
                                                        distribucion.CantidadAsignada = cant;
                                                        distribucionList.Add(distribucion);
                                                        n++;

                                                    });
                                                }

                                                if (setearDeposito)
                                                {
                                                    // Crear una lista de tuplas (Deposito, Porcentaje) para la selección aleatoria ponderada
                                                    var distribucionesParaSeleccion = distribucionList.Select(d => (d.Deposito, d.PorcentajeAsignado, d.PiesTipo)).ToList();
                                                    var depositoPorcentaje = asignacionDepositoList.Select(d => d.Deposito).ToList();
                                                    // Seleccionar un depósito aleatorio basado en los porcentajes
                                                    var depositoElegido2 = SeleccionarDepositoAleatorio(distribucionesParaSeleccion, peticion.Contenedor.Count());

                                                   

                                                    resultado.NumeroContenedor = cont.NumeroContenedor;
                                                    resultado.Deposito = depositoElegido2.Deposito;
                                                    resultado.RegistroCaso4 = "------ ";
                                                    resultado.TipoCaso = "POR CLIENTE ESPECIAL" ;
                                                    asignacionDepositoList.Add(resultado);

                                                    if (depositoElegido2.PiesTipo != null && depositoElegido2.PiesTipo.Contains("20"))
                                                    {
                                                        int m = l;
                                                        if (peticion.Contenedor.Count() > m + 1)
                                                        {
                                                            if (peticion.Contenedor[m + 1] != null)
                                                            {
                                                                Resultado resultado2 = new Resultado();
                                                                resultado2.NumeroContenedor = peticion.Contenedor[m + 1].NumeroContenedor;
                                                                resultado2.Deposito = depositoElegido2.Deposito;
                                                                resultado2.RegistroCaso4 = "------ ";
                                                                resultado2.TipoCaso = "POR CLIENTE ESPECIAL" ;
                                                                asignacionDepositoList.Add(resultado2);
                                                                l++;
                                                            }
                                                        }

                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            codigoSalida = BrmConstants.CODIGO_OP_ERROR;
                                            resultado.NumeroContenedor = cont.NumeroContenedor;
                                            // En cada vuelta, asignamos el siguiente depósito en la lista
                                            resultado.Deposito = null;
                                            resultado.RegistroCaso4 = "----";
                                            resultado.TipoCaso = "ERROR: SIN REGLAS";
                                            asignacionDepositoList.Add(resultado);
                                        }

                                    }
                                }
                            }
                        }
                    }
                    i++;
                };

                return generarRespuesta(codigoSalida, asignacionDepositoList, distribucionList);
            }
            catch (Exception ex)
            {
                await loggerDb.GenerarLog(ex.Message, 4, 0);
                Console.WriteLine(ex.StackTrace);
                _logger.LogError(ex.Message, ex);
                return generarRespuesta(BrmConstants.CODIGO_OP_ERROR, null, null);
            }
        }

        private StringBuilder generarQueryRut()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERRut");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (RutConsignatario = @rutConsignatario OR RutConsignatario = 'ALL') AND (RutClientePaga = @rutClientePaga OR RutClientePaga = 'ALL')");
            query.Append(" AND (PuertoDescarga = @puertoDescarga OR PuertoDescarga = 'ALL') AND (BL = @bl OR BL = 'ALL')");
            query.Append(" AND (PiesTipo = @piesTipo OR PiesTipo = 'ALL') AND (NOR = @nor OR NOR = 'ALL')");
            query.Append(" AND (PuertoEmbarque = @puertoEmbarque OR PuertoEmbarque = 'ALL') AND (Contenedor = @contenedor OR Contenedor = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }

        private StringBuilder generarQueryBL()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERBL");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (BL = @bl OR BL = 'ALL') AND (Contenedor = @contenedor OR Contenedor = 'ALL')");
            query.Append(" AND (PiesTipo = @piesTipo OR PiesTipo = 'ALL')");
            query.Append(" AND (NOR = @nor OR NOR = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }

        private StringBuilder generarQueryContrato()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERContrato");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (PuertoEmbarque = @puertoEmbarque OR PuertoEmbarque = 'ALL') AND (Contrato = @contrato OR Contrato = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }

        private StringBuilder generarQueryPorcentual()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERRutPorcentual");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (RutConsignatario = @rutConsignatario OR RutConsignatario = 'ALL') AND (RutClientePaga = @rutClientePaga OR RutClientePaga = 'ALL')");
            query.Append(" AND (PuertoDescarga = @puertoDescarga OR PuertoDescarga = 'ALL') AND (PiesTipo = @piesTipo OR PiesTipo = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }
        private StringBuilder generarQueryRecalada()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERRecalada");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (Nave = @nave OR Nave = 'ALL') AND (Viaje = @viaje OR Viaje = 'ALL')");
            query.Append(" AND (Destino = @destino OR Destino = 'ALL') AND (Descarga = @descarga OR Descarga = 'ALL')");
            query.Append(" AND (PiesTipo = @piesTipo OR PiesTipo = 'ALL') AND (NOR = @nor OR NOR = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }
        private StringBuilder generarQueryClienteEspecial()
        {
            StringBuilder query = new StringBuilder();

            query.Append("SELECT * FROM tbDistribucionEVERClienteEspecial");
            query.Append(" WHERE Activo = 'true' AND (Operador = @operador OR Operador = 'ALL')");
            query.Append(" AND (RutConsignatario = @rutConsignatario OR RutConsignatario = 'ALL') AND (RutClientePaga = @rutClientePaga OR RutClientePaga = 'ALL')");
            query.Append(" AND (PuertoOrigen = @puertoOrigen OR PuertoOrigen = 'ALL') AND (PiesTipo = @piesTipo OR PiesTipo = 'ALL')");
            query.Append(" AND (NOR = @nor OR NOR = 'ALL')");
            query.Append(" AND @fecha >= FechaVigenciaDesde");
            query.Append(" AND @fecha <= FechaVigenciaHasta");

            return query;
        }

        private StringBuilder generarQueryConfig()
        {
            StringBuilder query = new StringBuilder();
            query.Append("SELECT Valor FROM tbDistribucionEVERConfig WHERE NombreTabla = @nombreTabla");

            return query;

        }
        private void generarParametro(Dictionary<string, object> parametros, string nombre, object valor)
        {
            parametros.Add(nombre, valor);
        }

        private int countAllOcurrencesRecalada(tbDistribucionEVERRecalada recaladas)
        {
            int count = 0;
            // Obtener todas las propiedades públicas del DTO
            PropertyInfo[] propiedades = typeof(tbDistribucionEVERRecalada).GetProperties();

            foreach (var propiedad in propiedades)
            {
                // Obtener el valor de la propiedad en la instancia del DTO
                object valorPropiedad = propiedad.GetValue(recaladas);

                // Comparar el valor de la propiedad con el valor buscado
                if (valorPropiedad != null && valorPropiedad.Equals("ALL"))
                {
                    count++;
                }
            }

            return count;
        }


        public static (string Deposito, string PiesTipo) SeleccionarDepositoAleatorio(List<(string Deposito, double Porcentaje, string PiesTipo)> distribucion, int cantidadContenedores)
        {
            var random = new Random();
            // Crear una lista acumulativa de porcentajes para facilitar la selección
            List<int> acumulados = new List<int>();
            List<(string Deposito, double Porcentaje, string PiesTipo)> dtb = new List<(string Deposito, double Porcentaje, string PiesTipo)>();
            dtb = distribucion;
            int total = 0;
            // Almacena la cantidad de %
            foreach (var dist in distribucion.ToList())
            {
                // Si el deposito tiene 0%, lo elimina
                if (dist.Porcentaje == 0)
                {
                    dtb.Remove(dist);
                    continue;
                }
                // Acumular solo el porcentaje original
                total += (int)Math.Round(dist.Porcentaje, MidpointRounding.AwayFromZero);
                acumulados.Add(total);
            }

            // Generar un número aleatorio entre 0 y el total de porcentajes

            double valorAleatorio = random.Next((int)total);

            int i = 0;
            double tot = 0;

            for (i = 0; i < acumulados.Count(); i++)
            {
                tot += acumulados[i];
                if (tot >= valorAleatorio) break;
                // Si porcentaje asignado mediante for es mayor al porcentaje que viene por defecto, busca de nuevo
            }
            return (dtb[i].Deposito, dtb[i].PiesTipo);


        }

        private ResponseDto generarRespuesta(int codigoEstado, List<Resultado>? resultados, List<DistribucionDeposito>? depositos)
        {
            return new ResponseDto()
            {
                Resultado = resultados,
                DistribucionDeposito = depositos,
                Estado = codigoEstado
            };
        }
    }
}
