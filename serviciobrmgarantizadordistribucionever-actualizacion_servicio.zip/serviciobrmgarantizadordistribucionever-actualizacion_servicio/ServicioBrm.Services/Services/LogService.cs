﻿using ServicioBrm.Entities.Entities.Others;
using ServicioBrm.Repository.IRepository;
using ServicioBrm.Services.Base;
using ServicioBrm.Services.IServices;
using System;
using System.Threading.Tasks;

namespace ServicioBrm.Services.Services
{
    public class LogService : BaseService, ILogService
    {
        private readonly IAutLogRepository autLogRepository;

        public LogService(IAutLogRepository autLogRepository)
        {
            this.autLogRepository = autLogRepository;
        }
        public async Task<AutLog> CrearOEditar(AutLog log)
        {
            return await autLogRepository.InsertOrUpdate(log).ConfigureAwait(false);
        }

        public async Task<AutLog> GenerarLog(string descripcion, int tipoLog, int userId)
        {
            if (string.IsNullOrEmpty(descripcion) && descripcion.Length > 250)
            {
                descripcion = descripcion.Substring(0, 250);
            }
            AutLog autLog = new AutLog();
            autLog.LogUserId = userId;
            autLog.LogDescription = descripcion;
            autLog.LogTypeId = tipoLog;
            autLog.LogDate = DateTime.Now;
            return await CrearOEditar(autLog);
        }
    }
}
