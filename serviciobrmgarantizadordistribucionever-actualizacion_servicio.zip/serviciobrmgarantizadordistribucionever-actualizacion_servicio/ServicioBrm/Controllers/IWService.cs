﻿using ServicioBrm.Dto.Dto.Request;
using ServicioBrm.Dto.Dto.Response;
using System.ServiceModel;
using System.Threading.Tasks;

namespace ServicioBrm
{
    [ServiceContract]
    public interface IWService
    {
        [OperationContract]
        Task<ResponseDto> generarTarifa(RequestDto requestDto);

    }
}
