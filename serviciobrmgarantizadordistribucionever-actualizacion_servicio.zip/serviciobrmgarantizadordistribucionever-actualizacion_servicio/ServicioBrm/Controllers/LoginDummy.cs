﻿using Microsoft.AspNetCore.Mvc;
using ServicioBrm.Dto.Dto;
using ServicioBrm.Services.IServices;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ServicioBrm.Controllers
{
    [Route("api/[controller]")]
    public class LoginDummy : Controller
    {
        private readonly IAuthenticationService _authenticationService;

        public LoginDummy(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }


        // Está clase se encargará de retornar el token con los atributos y los permisos
        // Que sean necesarios para probar el módulo
        // Se van a generar tantos métodos como personas o permisos sean necesario probar


        [HttpGet("ObtenerAdmin")]
        public async Task<ActionResult> ObtenerAdmin()
        {
            var usuarioDummyDto = new UsuarioDummyDto()
            {
                UserName = "Vasquez Camilo (SCL UMAR)",
                UserEmail = "mail@ultramar.cl",
                NombreCuenta = "useraccount",
                Branch = "Valparaíso",
                Company = "Ultramar Agencia Marítima"
            };
            return Ok(new { Token = _authenticationService.obtenerToken(usuarioDummyDto) });
        }

        [HttpPost("ObtenerASoloLectura")]
        public async Task<ActionResult> ObtenerSoloLectura()
        {
            var usuarioDummyDto = new UsuarioDummyDto()
            {
                UserName = "Vasquez Camilo (SCL UMAR)",
                UserEmail = "mail@ultramar.cl",
                NombreCuenta = "useraccount",
                Branch = "Valparaíso",
                Company = "Ultramar Agencia Marítima"
            };
            return Ok(new { Token = _authenticationService.obtenerToken(usuarioDummyDto) });
        }
    }
}
