﻿using Microsoft.Extensions.Logging;
using ServicioBrm.Dto.Dto.Request;
using ServicioBrm.Dto.Dto.Response;
using ServicioBrm.Service.Services.IServices;
using System;
using System.Threading.Tasks;

namespace ServicioBrm
{
    public class WService : IWService
    {
        private readonly IBrmService _brmService;
        private readonly ILogger _logger;

        public WService(IBrmService brmService,
            ILogger<WService> logger)
        {
            _brmService = brmService;
            _logger = logger;
        }

        public async Task<ResponseDto> generarTarifa(RequestDto requestDto)
        {
            try
            {
                _logger.LogInformation("[ServicioBrm] Request: " + requestDto.ToString());
                var res = await _brmService.generarTarifa(requestDto);
                _logger.LogInformation("[ServicioBrms] Response: " + res.ToString());
                return res;
            }
            catch (Exception ex)
            {
                _logger.LogError("[ServicioBrm] Error: " + ex.Message + ex.StackTrace);
                return (new ResponseDto()
                {                    
                });
            }
        }
    }
}
