﻿namespace ServicioBrm.Settings
{
    public class AppTokens
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
    }
}
