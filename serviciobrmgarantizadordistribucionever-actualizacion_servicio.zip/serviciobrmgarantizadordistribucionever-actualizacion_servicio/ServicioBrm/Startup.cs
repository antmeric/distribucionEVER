using DbMigrationLib;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using ServicioBrm.Commons.Connection;
using ServicioBrm.Middleware;
using ServicioBrm.Repository.Generics;
using ServicioBrm.Repository.IRepository;
using ServicioBrm.Repository.Repository;
using ServicioBrm.Service.Services;
using ServicioBrm.Service.Services.IServices;
using ServicioBrm.Services.IServices;
using ServicioBrm.Services.Mail;
using ServicioBrm.Services.Mail.IMail;
using ServicioBrm.Services.Services;
using ServicioBrm.Settings;
using SoapCore;
using SoapCore.Extensibility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.ServiceModel;
using System.Text;
using static ServicioBrm.Commons.Connection.IConnectionDb;

namespace ServicioBrm
{
    public class Startup
    {
        public IConfiguration IConfiguration { get; }
        private readonly ILogger _logger;
        private readonly IServiceProvider _serviceProvider;
        public IContainer ApplicationContainer { get; private set; }


        public Startup(IConfiguration configuration,
            ILogger<Startup> logger,
            IServiceProvider serviceProvider)
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            IConfiguration = GetConfiguration(environment);
            _logger = logger;
            _serviceProvider = serviceProvider;

        }

        private static IConfigurationRoot GetConfiguration(string env)
        {
            return new ConfigurationBuilder()
                .SetBasePath(Path.Combine(AppContext.BaseDirectory))
                .AddJsonFile("appsettings." + env + ".json", optional: true, reloadOnChange: true)
                .Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<AppSetting>(IConfiguration.GetSection("AppSettings"));
            services.Configure<IISServerOptions>(options => { });
            IOptions<AppSetting> settings = _serviceProvider.GetService<IOptions<AppSetting>>();

            #region DbMigration
            DbMigrationsBuilder.Crear()
                .AddILogger(_logger)
                .AddStringConection(IConfiguration.GetConnectionString("BrmDb"))
                .RepararDb(settings.Value.RepairActivated)
                .Build();
            #endregion

            #region conexiones correspondiente a repositorios y servicios
            services.AddTransient<IDbConnection>(db => new SqlConnection(
                IConfiguration.GetConnectionString("BrmDb")));
            #endregion

            #region configuracion email
            services.AddScoped<IMailSettingsContainer>(msc => new MailSettingsContainer(settings.Value.MailSettings));
            #endregion

            ConfigurarRepositorios(services);
            ConfigurarServicios(services);
            //ConfigurarSeguridad(services);
            services.AddTransient<IMailService, MailService>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v3.1", new OpenApiInfo
                {
                    Title = "Kernel",
                    Version = "v3.1",
                    Description = "Proyecto Kernel 3.1",
                    Contact = new OpenApiContact
                    {
                        Name = "Umar",
                        Email = string.Empty
                    }
                });

            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IWebHostEnvironment env,
            IServiceProvider serviceProvider,
            IHostApplicationLifetime appLifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseMiddleware(typeof(ErrorHandlingMiddleware));
            app.UseStaticFiles();

            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
            });

            app.Use(async (context, next) =>
            {
                if (context.Request.Method == "POST")
                {
                    context.Request.Headers.TryGetValue("Authorization", out var credentials);
                    var userPassBase64 = credentials.ToString().Replace("Basic ", "");
                    var userPassByte = Convert.FromBase64String(userPassBase64);
                    var userPassArray = Encoding.Default.GetString(userPassByte);
                    var userPass = userPassArray.Split(new[] { ':' }, 2);
                    if (userPass.Length == 2)
                    {
                        var userReal = IConfiguration.GetSection("Authentication")["user"];
                        var passReal = IConfiguration.GetSection("Authentication")["password"];

                        if (!string.Equals(userPass[0], userReal) || !string.Equals(userPass[1], passReal))
                        {
                            SetResponse(context, 401);
                        }
                        else
                        {
                            await next.Invoke();
                        }
                    }
                    else
                    {
                        SetResponse(context, 401);
                    }
                }
                else
                {
                    await next.Invoke();
                }

            });

            app.UseSoapEndpoint<IWService>("/wsbrm_distribucionEVER.asmx", new SoapEncoderOptions(), SoapSerializer.DataContractSerializer, true);


        }

        private static void SetResponse(HttpContext context, int code)
        {
            context.Response.StatusCode = code;
            context.Response.ContentType = "application/text";
        }

        public void ConfigurarServicios(IServiceCollection services)
        {
            services.AddTransient<BrmDb>(db => new BrmDb(IConfiguration.GetConnectionString("BrmDb")));

            services.AddTransient<ServiceResolverDb>(serviceProvider => key =>
            {
                switch (key)
                {
                    case "BrmDb":
                        return serviceProvider.GetService<BrmDb>();
                    case "HangFireDb":
                        return serviceProvider.GetService<HangFireConnectionDb>();
                    default:
                        throw new KeyNotFoundException();
                }
            });
            services.TryAddSingleton<IWService, WService>();
            services.AddTransient<IBrmService, BrmService>();
            services.AddTransient<IAuthenticationService, AuthenticationService>();
            services.AddTransient<ILogService, LogService>();
            services.AddSoapCore();
            //services.TryAddSingleton<IFaultExceptionTransformer, DefaultFaultExceptionTransformer>();

        }

        public void ConfigurarRepositorios(IServiceCollection services)
        {
            services.AddTransient<ItbDistribucionEVERBlRepository, tbDistribucionEVERBlRepository>();
            services.AddTransient<ItbDistribucionEVERRecaladaRepository, tbDistribucionEVERRecaladaRepository>();
            services.AddTransient<ItbDistribucionEVERContratoRepository, tbDistribucionEVERContratoRepository>();
            services.AddTransient<ItbDistribucionEVERClienteEspecialRepository, tbDistribucionEVERClienteEspecialRepository>();
            services.AddTransient<ItbDistribucionEVERRutRepository, tbDistribucionEVERRutRepository>();
            services.AddTransient<ItbDistribucionEVERRutPorcentualRepository, tbDistribucionEVERRutPorcentualRepository>();
            services.AddTransient<ItbDistribucionEVERConfigRepository, tbDistribucionEVERConfigRepository>();
            services.AddTransient<IAutLogTypesRepository, AutLogTypesRepository>();
            services.AddTransient<IAutLogRepository, AutLogRepository>();
            services.AddTransient<IGenericRepository<dynamic>, GenericQueryRepository<dynamic>>();
        }
        private void ConfigurarSeguridad(IServiceCollection services)
        {
            services.Configure<AppTokens>(IConfiguration.GetSection("Tokens"));
            IOptions<AppTokens> settings = services.BuildServiceProvider().GetService<IOptions<AppTokens>>();

        }

    }
}